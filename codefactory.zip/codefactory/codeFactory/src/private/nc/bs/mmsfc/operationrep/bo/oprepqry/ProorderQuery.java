package nc.bs.mmsfc.operationrep.bo.oprepqry;

import nc.util.mmf.framework.base.MMVOUtil;
import nc.util.mmf.framework.base.MMValueCheck;
import nc.vo.mmsfc.operationrep.entity.OprepItemVO;
import nc.vo.mmsfc.operationrep.entity.OprepQcVO;
import nc.vo.mmsfc.operationrep.entity.ProoorderVO;
import nc.vo.pub.BeanHelper;
import nc.vo.pub.SuperVO;
import nc.vo.pubapp.pattern.pub.MapList;

import java.util.ArrayList;
import java.util.List;

public class ProorderQuery {
    public ProorderQuery() {
    }
    public MapList<String, ProoorderVO> queryByHeadIds(String[] hids) {
        ProoorderVO[] prodVOs = (ProoorderVO[]) MMVOUtil.query(ProoorderVO.class, "pk_oprep", hids);
        for (ProoorderVO prodVO : prodVOs) {

        }
        MapList<String, ProoorderVO> proorder = MMVOUtil.groupToMapList(prodVOs, "pk_oprep");
        return proorder.size() == 0 ? new MapList<String, ProoorderVO>() : proorder;
    }

//    public ProoorderVO[] queryItemAllInfo(ProoorderVO[] prodVOs) {
//        if (prodVOs != null && prodVOs.length != 0) {
//            List<ProoorderVO> list = new ArrayList();
//            List<String> bids = MMVOUtil.getStrValue(prodVOs, "pk_proorder");
//            if (bids.size() > 0) {
//
//                ProoorderVO[] var6 = prodVOs;
//                int var7 = prodVOs.length;
//
//                for(int var8 = 0; var8 < var7; ++var8) {
//                    ProoorderVO item = var6[var8];
//                    ProoorderVO nItem = (ProoorderVO)item.clone();
//                    list.add(nItem);
//                }
//            }
//
//            return list.size() > 0 ? (ProoorderVO[])list.toArray(new ProoorderVO[0]) : prodVOs;
//        } else {
//            return prodVOs;
//        }
//    }
    public static void syncMapToFields(SuperVO vo) {
        if (vo == null) return;
        // getAttributeNames() �᷵�������ֶ��������� Meta��
        String[] names = vo.getAttributeNames();
        for (String name : names) {
            try {
                // getAttributeValue() �� Map ��
                Object value = vo.getAttributeValue(name);
                // BeanHelper.setProperty() �� setter д���ֶ�
                BeanHelper.setProperty(vo, name, value);
            } catch (Exception ignore) {
            }
        }
    }
}
