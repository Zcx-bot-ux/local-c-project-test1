package nc.bs.mmsfc.operationrep.bo.oprepqry;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import nc.impl.pubapp.pattern.data.view.EfficientViewQuery;
import nc.impl.pubapp.pattern.data.vo.SchemeVOQuery;
import nc.ui.querytemplate.querytree.IQueryScheme;
import nc.util.mmf.framework.base.MMArrayUtil;
import nc.util.mmf.framework.base.MMNumberUtil;
import nc.util.mmf.framework.base.MMVOUtil;
import nc.util.mmf.framework.base.MMValueCheck;


import nc.vo.mmsfc.operationrep.entity.*;
import nc.vo.mmsfc.operationrep.util.ItemConvertUtil;
import nc.vo.mmsfc.operationrep.util.OprepHelper;
import nc.vo.mmsfc.operationrep.view.OprepMOQueryNoViewVO;
import nc.vo.pub.ISuperVO;
import nc.vo.pub.lang.UFDouble;
import nc.vo.pubapp.pattern.pub.MapList;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import nc.vo.pub.CircularlyAccessibleValueObject;


public class OprepBillQuery {
    public AggOprepVO[] query(String[] ids) {
        if (MMArrayUtil.isEmpty(ids)) {
            return new AggOprepVO[0];
        } else {
            Set<String> set = new HashSet();
            set.addAll(Arrays.asList(ids));

            OprepVO[] heads = (OprepVO[]) MMVOUtil.query(OprepVO.class, "pk_oprep", (String[]) set.toArray(new String[0]));

            if (MMArrayUtil.isEmpty(heads)) {
                return null;
            } else {
                OprepItemQuery itemQuery = new OprepItemQuery();
                ProorderQuery ProdQuery = new ProorderQuery();
                MapList<String, OprepItemVO> itemMapList = itemQuery.queryByHeadIds((String[]) set.toArray(new String[0]));
                MapList<String, ProoorderVO> ProdMapList = ProdQuery.queryByHeadIds((String[]) set.toArray(new String[0]));
                List<AggOprepVO> aggList = new ArrayList();
                List<OprepItemVO> itemList = null;
                List<ProoorderVO> ProdList = null;
                AggOprepVO agg = null;
                OprepVO[] var9 = heads;
                int var10 = heads.length;

                for (int var11 = 0; var11 < var10; ++var11) {
                    OprepVO head = var9[var11];
                    agg = new AggOprepVO();
                    agg.setParentVO(head);
                    itemList = itemMapList.get(head.getPk_oprep());
                    if (itemList != null && itemList.size() > 0) {
                        agg.setItemVO((OprepItemVO[]) itemList.toArray(new OprepItemVO[itemList.size()]));
                    }
                    ProdList = ProdMapList.get(head.getPk_oprep());
                    if(ProdList != null && ProdList.size() > 0) {
                        agg.setProoorderVO((ProoorderVO[]) ProdList.toArray(new ProoorderVO[ProdList.size()]));
                    }else{
                        agg.setProoorderVO(new ProoorderVO[0]);
                    }


                    aggList.add(agg);
                }

                return (AggOprepVO[]) aggList.toArray(new AggOprepVO[aggList.size()]);
            }
        }
    }
    public OprepBillQuery() {
    }

    public AggOprepVO[] queryOprepByQueryScheme(IQueryScheme scheme, String order) {
        SchemeVOQuery<OprepVO> query = new SchemeVOQuery(OprepVO.class);
        query.setUsedistinct(true);
        ISuperVO[] parents = query.query(scheme, order);
        int length = parents.length;
        AggOprepVO[] bills = new AggOprepVO[length];

        for(int i = 0; i < length; ++i) {
            bills[i] = new AggOprepVO();
            bills[i].setParent(parents[i]);
        }

        if (length > 0) {
            OprepItemQuery bo = new OprepItemQuery();
            bills[0].setItemVO(bo.queryByHeadId(bills[0].getParentVO().getPk_oprep()));
        }

        return bills;
    }

    public AggOprepVO[] query(AggOprepVO[] bills) {
        OprepHelper helper = new OprepHelper();
        String[] hids = helper.getHids(bills);
        return this.query(hids);
    }


    public AggOprepVO query(String id) {
        AggOprepVO[] vos = this.query(new String[]{id});
        return vos != null && vos.length != 0 ? vos[0] : null;
    }

    public AggOprepVO[] queryByMObid(String[] procids) {
        OprepItemVO[] bodys = (OprepItemVO[])MMVOUtil.query(OprepItemVO.class, "cmoprocedureid", procids);
        if (MMValueCheck.isEmpty(bodys)) {
            return null;
        } else {
            List<String> headids = MMVOUtil.getStrValue(bodys, "pk_oprep");
            OprepVO[] heads = (OprepVO[])MMVOUtil.query(OprepVO.class, "pk_oprep", headids);
            OprepItemQuery bo = new OprepItemQuery();
            OprepItemVO[] items = bo.queryItemAllInfo(bodys);
            MapList<String, OprepItemVO> bMap = MMVOUtil.groupToMapList(items, "pk_oprep");
            List<AggOprepVO> reList = new ArrayList();
            OprepVO[] var9 = heads;
            int var10 = heads.length;

            for(int var11 = 0; var11 < var10; ++var11) {
                OprepVO head = var9[var11];
                List<OprepItemVO> reItemList = bMap.get(head.getPk_oprep());
                if (reItemList.size() > 0) {
                    AggOprepVO bill = new AggOprepVO();
                    bill.setParentVO(head);
                    bill.setItemVO(ItemConvertUtil.buildFullDataItem((OprepItemVO[])reItemList.toArray(new OprepItemVO[0])));
                    reList.add(bill);
                }
            }

            if (reList.size() > 0) {
                return (AggOprepVO[])reList.toArray(new AggOprepVO[0]);
            } else {
                return null;
            }
        }
    }

    public Map<String, String> queryProcNoByOprepbid(String[] qcids) {
        Map<String, String> map = new HashMap();
        if (MMArrayUtil.isEmpty(qcids)) {
            return map;
        } else {
            EfficientViewQuery<OprepMOQueryNoViewVO> query = new EfficientViewQuery(OprepMOQueryNoViewVO.class);
            OprepMOQueryNoViewVO[] views = (OprepMOQueryNoViewVO[])query.query(qcids);
            OprepMOQueryNoViewVO[] var5 = views;
            int var6 = views.length;

            for(int var7 = 0; var7 < var6; ++var7) {
                OprepMOQueryNoViewVO view = var5[var7];
                map.put((String)view.getAttributeValue("pk_oprep_qc"), (String)view.getAttributeValue("vboperationno"));
            }

            return map;
        }
    }

    public Map<String, String> queryProcIdByOprepbid(String[] qcids) {
        Map<String, String> map = new HashMap();
        if (MMArrayUtil.isEmpty(qcids)) {
            return map;
        } else {
            EfficientViewQuery<OprepMOQueryNoViewVO> query = new EfficientViewQuery(OprepMOQueryNoViewVO.class);
            OprepMOQueryNoViewVO[] views = (OprepMOQueryNoViewVO[])query.query(qcids);
            OprepMOQueryNoViewVO[] var5 = views;
            int var6 = views.length;

            for(int var7 = 0; var7 < var6; ++var7) {
                OprepMOQueryNoViewVO view = var5[var7];
                map.put((String)view.getAttributeValue("pk_oprep_qc"), (String)view.getAttributeValue("cmoprocedureid"));
            }

            return map;
        }
    }

    public Map<String, UFDouble> queryNnumByOprepbid(String[] qcids) {
        Map<String, UFDouble> map = new HashMap();
        if (MMArrayUtil.isEmpty(qcids)) {
            return map;
        } else {
            EfficientViewQuery<OprepMOQueryNoViewVO> query = new EfficientViewQuery(OprepMOQueryNoViewVO.class);
            OprepMOQueryNoViewVO[] views = (OprepMOQueryNoViewVO[])query.query(qcids);
            List<String> hids = new ArrayList();
            OprepMOQueryNoViewVO[] var6 = views;
            int var7 = views.length;

            for(int var8 = 0; var8 < var7; ++var8) {
                OprepMOQueryNoViewVO view = var6[var8];
                String pk_oprep = (String)view.getAttributeValue("pk_oprep");
                hids.add(pk_oprep);
            }

            AggOprepVO[] vos = this.query((String[])hids.toArray(new String[0]));
            AggOprepVO[] aggs = OprepHelper.toDisViewVO(vos);
            List<OprepItemVO> itemVOs = new ArrayList();
            AggOprepVO[] var20 = aggs;
            int var22 = aggs.length;

            int var11;
            for(var11 = 0; var11 < var22; ++var11) {
                AggOprepVO bill = var20[var11];
                if (!MMValueCheck.isEmpty(bill.getItemVO())) {
                    OprepItemVO[] var13 = bill.getItemVO();
                    int var14 = var13.length;

                    for(int var15 = 0; var15 < var14; ++var15) {
                        OprepItemVO item = var13[var15];
                        item.setNbonenum(MMNumberUtil.sub((UFDouble)item.getAttributeValue("nbqnum"), new UFDouble[]{(UFDouble)item.getAttributeValue("nbqreworkmonum")}));
                        item.setNbastonenum(MMNumberUtil.sub((UFDouble)item.getAttributeValue("nbqastnum"), new UFDouble[]{(UFDouble)item.getAttributeValue("nbqastreworkmonum")}));
                        itemVOs.add(item);
                    }
                }
            }

            OprepItemVO[] items = ItemConvertUtil.buildFullDataItem((OprepItemVO[])itemVOs.toArray(new OprepItemVO[itemVOs.size()]));
            OprepItemVO[] var23 = items;
            var11 = items.length;

            for(int var24 = 0; var24 < var11; ++var24) {
                OprepItemVO oprepItemVO = var23[var24];
                map.put(oprepItemVO.getCbqid(), oprepItemVO.getNbonenum());
            }

            return map;
        }
    }

    public Map<String, UFDouble> queryOprepNumByMOProcid(String[] procids) {
        Map<String, UFDouble> map = new HashMap();
        OprepItemVO[] items = (OprepItemVO[])MMVOUtil.query(OprepItemVO.class, "cmoprocedureid", procids, new String[]{"cmoprocedureid", "nbastoprepnum", "nboprepnum"});
        if (MMValueCheck.isEmpty(items)) {
            return map;
        } else {
            MapList<String, OprepItemVO> bMap = MMVOUtil.groupToMapList(items, "cmoprocedureid");

            Map.Entry entry;
            UFDouble num;
            for(Iterator var5 = bMap.entrySet().iterator(); var5.hasNext(); map.put((String)entry.getKey(), num)) {
                entry = (Map.Entry)var5.next();
                List<OprepItemVO> reItemList = (List)entry.getValue();
                num = UFDouble.ZERO_DBL;
                OprepItemVO item;
                if (reItemList != null) {
                    for(Iterator var9 = reItemList.iterator(); var9.hasNext(); num = MMNumberUtil.add(new UFDouble[]{num, item.getNboprepnum()})) {
                        item = (OprepItemVO)var9.next();
                    }
                }
            }

            return map;
        }
    }

    public Map<String, Boolean> hasOprepBillByProcid(String[] procids) {
        Map<String, Boolean> map = new HashMap();
        OprepItemVO[] items = (OprepItemVO[])MMVOUtil.query(OprepItemVO.class, "cmoprocedureid", procids, new String[]{"pk_oprep_b", "cmoprocedureid"});
        if (MMValueCheck.isEmpty(items)) {
            return map;
        } else {
            MapList<String, OprepItemVO> bMap = MMVOUtil.groupToMapList(items, "cmoprocedureid");
            Iterator var5 = bMap.entrySet().iterator();

            while(true) {
                while(var5.hasNext()) {
                    Map.Entry<String, List<OprepItemVO>> entry = (Map.Entry)var5.next();
                    List<OprepItemVO> reItemList = (List)entry.getValue();
                    if (reItemList != null && reItemList.size() > 0) {
                        map.put((String)entry.getKey(), Boolean.TRUE);
                    } else {
                        map.put((String)entry.getKey(), Boolean.FALSE);
                    }
                }

                String[] var9 = procids;
                int var10 = procids.length;

                for(int var11 = 0; var11 < var10; ++var11) {
                    String procid = var9[var11];
                    if (!bMap.containsKey(procid)) {
                        map.put(procid, Boolean.FALSE);
                    }
                }

                return map;
            }
        }
    }

    public AggOprepVO[] queryByQcIds(String[] qids) {
        OprepQcVO[] qcs = (OprepQcVO[])MMVOUtil.query(OprepQcVO.class, "pk_oprep_qc", qids);
        if (MMValueCheck.isEmpty(qcs)) {
            return null;
        } else {
            MapList<String, OprepQcVO> map = MMVOUtil.groupToMapList(qcs, "pk_oprep_b");
            OprepItemVO[] bodys = (OprepItemVO[])MMVOUtil.query(OprepItemVO.class, "pk_oprep_b", map.keySet());
            if (MMValueCheck.isEmpty(bodys)) {
                return null;
            } else {
                List<String> headids = new ArrayList();
                OprepItemVO[] var6 = bodys;
                int var7 = bodys.length;

                for(int var8 = 0; var8 < var7; ++var8) {
                    OprepItemVO body = var6[var8];
                    headids.add(body.getPk_oprep());
                    if (map.containsKey(body.getPk_oprep_b()) && MMValueCheck.isNotEmpty(map.get(body.getPk_oprep_b()))) {
                        body.setPk_oprep_qc((OprepQcVO[])map.get(body.getPk_oprep_b()).toArray(new OprepQcVO[0]));
                    }
                }

                OprepVO[] heads = (OprepVO[])MMVOUtil.query(OprepVO.class, "pk_oprep", headids);
                if (MMValueCheck.isEmpty(heads)) {
                    return null;
                } else {
                    MapList<String, OprepItemVO> bMap = MMVOUtil.groupToMapList(bodys, "pk_oprep");
                    List<AggOprepVO> reList = new ArrayList();
                    OprepVO[] var18 = heads;
                    int var10 = heads.length;

                    for(int var11 = 0; var11 < var10; ++var11) {
                        OprepVO head = var18[var11];
                        List<OprepItemVO> reItemList = bMap.get(head.getPk_oprep());
                        if (reItemList.size() > 0) {
                            AggOprepVO bill = new AggOprepVO();
                            bill.setParentVO(head);
                            bill.setItemVO(ItemConvertUtil.buildFullDataItem((OprepItemVO[])reItemList.toArray(new OprepItemVO[0])));
                            reList.add(bill);
                        }
                    }

                    if (reList.size() > 0) {
                        return (AggOprepVO[])reList.toArray(new AggOprepVO[0]);
                    } else {
                        return null;
                    }
                }
            }
        }
    }
}