//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package nccloud.web.mmsfc.operationrep.action;


import nc.itf.mmsfc.operationrep.IOprepQuery;
import nc.vo.ml.NCLangRes4VoTransl;
import nc.vo.mmsfc.operationrep.entity.AggOprepVO;
import nc.vo.mmsfc.operationrep.entity.OprepItemVO;
import nc.vo.mmsfc.operationrep.util.ItemConvertUtil;
import nccloud.framework.core.exception.ExceptionUtils;
import nccloud.framework.core.json.IJson;

import nccloud.framework.service.ServiceLocator;
import nccloud.framework.web.action.itf.ICommonAction;
import nccloud.framework.web.container.IRequest;
import nccloud.framework.web.json.JsonFactory;
import nccloud.framework.web.ui.model.row.Cell;
import nccloud.framework.web.ui.model.row.Row;
import nccloud.framework.web.ui.pattern.billcard.BillCard;
import nccloud.framework.web.ui.pattern.billcard.BillCardOperator;
import nccloud.framework.web.ui.pattern.grid.Grid;
import nccloud.mmsfc.operationrep.pub.entity.QueryInfoByPKS;
import nccloud.web.mmsfc.operationrep.util.OprepScaleUtil;



public class OprepCardQueryAction implements ICommonAction {

    public OprepCardQueryAction() {
    }

    public Object doAction(IRequest request) {
        String read = request.read();
        IJson json = JsonFactory.create();
        QueryInfoByPKS query = (QueryInfoByPKS)json.fromJson(read, QueryInfoByPKS.class);

        try {
            IOprepQuery service = (IOprepQuery) ServiceLocator.find(IOprepQuery.class);
            AggOprepVO[] vos = service.queryOprep(query.getPks());

            if (null == vos || vos.length == 0) {
                ExceptionUtils.wrapBusinessException(NCLangRes4VoTransl.getNCLangRes().getStrByID("5008100_0", "05008100-0004"));
            }


            OprepItemVO[] items = ItemConvertUtil.buildFullDataItem(vos[0].getItemVO());

            vos[0].setItemVO(items);




            BillCardOperator operator = new BillCardOperator(query.getPagecode());
            BillCard retcard = operator.toCard(vos[0]);
            this.afterProcess(retcard);
            return retcard;
        } catch (Exception var10) {
            ExceptionUtils.wrapBusinessException(var10.getMessage());
            return null;
        }
    }

    private void afterProcess(BillCard retcard) {
        OprepScaleUtil scale = new OprepScaleUtil();
        scale.processBillCard(retcard);
        Grid grid = retcard.getBody();
        if (grid != null && grid.getModel() != null && grid.getModel().getRows() != null) {
            Row[] rows = grid.getModel().getRows();
            Row[] var5 = rows;
            int var6 = rows.length;

            for(int var7 = 0; var7 < var6; ++var7) {
                Row row = var5[var7];
                Cell[] cells = row.getCells();
                Cell[] var10 = cells;
                int var11 = cells.length;

                for(int var12 = 0; var12 < var11; ++var12) {
                    Cell cell = var10[var12];
                    if (cell.getValue() != null && (cell.getDisplay() == null || "".equals(cell.getDisplay()))) {
                        cell.setDisplay(cell.getValue().toString());
                    }
                }
            }
        }

    }
}
