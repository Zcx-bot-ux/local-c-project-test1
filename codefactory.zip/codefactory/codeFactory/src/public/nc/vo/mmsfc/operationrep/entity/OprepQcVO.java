package nc.vo.mmsfc.operationrep.entity;


import nc.vo.pub.IVOMeta;
import nc.vo.pub.SuperVO;
import nc.vo.pub.lang.UFBoolean;
import nc.vo.pub.lang.UFDouble;
import nc.vo.pubapp.pattern.model.meta.entity.vo.VOMetaFactory;

public class OprepQcVO extends SuperVO {

	//���췽��
	public OprepQcVO() {
		super();
	}


    private transient java.lang.String pk_oprep_qc;
    private transient java.lang.Integer fqsrctype;
    private transient java.lang.Integer fqprocessmethod;
    private transient nc.vo.pub.lang.UFBoolean bqhaswr;
    private transient java.lang.String cqqcorgid;
    private transient java.lang.String cqqcorgvid;
    private transient java.lang.String cqqcid;
    private transient java.lang.String cqqcbid;
    private transient java.lang.String vqqcbillcode;
    private transient java.lang.String vqqcrowno;
    private transient java.lang.String fqdefecttype;
    private transient java.lang.String vqdefectnote;
    private transient java.lang.String cqchargepsnid;
    private transient java.lang.String cqchargedeptid;
    private transient java.lang.String cqchargedeptvid;
    private transient nc.vo.pub.lang.UFDouble nqastnum;
    private transient nc.vo.pub.lang.UFDouble nqnum;
    private transient nc.vo.pub.lang.UFDouble nqasttransfernum;
    private transient nc.vo.pub.lang.UFDouble nqtransfernum;
    private transient nc.vo.pub.lang.UFDouble nqastreworkmonum;
    private transient nc.vo.pub.lang.UFDouble nqreworkmonum;
    private transient java.lang.String vqdef1;
    private transient java.lang.String vqdef2;
    private transient java.lang.String vqdef3;
    private transient java.lang.String vqdef4;
    private transient java.lang.String vqdef5;
    private transient java.lang.String vqdef6;
    private transient java.lang.String vqdef7;
    private transient java.lang.String vqdef8;
    private transient java.lang.String vqdef9;
    private transient java.lang.String vqdef10;
    private transient java.lang.String vqdef11;
    private transient java.lang.String vqdef12;
    private transient java.lang.String vqdef13;
    private transient java.lang.String vqdef14;
    private transient java.lang.String vqdef15;
    private transient java.lang.String vqdef16;
    private transient java.lang.String vqdef17;
    private transient java.lang.String vqdef18;
    private transient java.lang.String vqdef19;
    private transient java.lang.String vqdef20;
	private java.lang.Integer dr = 0;
    private transient nc.vo.pub.lang.UFDateTime ts;
    private transient java.lang.String pk_oprep_b;


	public static final String PK_OPREP_QC = "pk_oprep_qc";
	public static final String FQSRCTYPE = "fqsrctype";
	public static final String FQPROCESSMETHOD = "fqprocessmethod";
	public static final String BQHASWR = "bqhaswr";
	public static final String CQQCORGID = "cqqcorgid";
	public static final String CQQCORGVID = "cqqcorgvid";
	public static final String CQQCID = "cqqcid";
	public static final String CQQCBID = "cqqcbid";
	public static final String VQQCBILLCODE = "vqqcbillcode";
	public static final String VQQCROWNO = "vqqcrowno";
	public static final String FQDEFECTTYPE = "fqdefecttype";
	public static final String VQDEFECTNOTE = "vqdefectnote";
	public static final String CQCHARGEPSNID = "cqchargepsnid";
	public static final String CQCHARGEDEPTID = "cqchargedeptid";
	public static final String CQCHARGEDEPTVID = "cqchargedeptvid";
	public static final String NQASTNUM = "nqastnum";
	public static final String NQNUM = "nqnum";
	public static final String NQASTTRANSFERNUM = "nqasttransfernum";
	public static final String NQTRANSFERNUM = "nqtransfernum";
	public static final String NQASTREWORKMONUM = "nqastreworkmonum";
	public static final String NQREWORKMONUM = "nqreworkmonum";
	public static final String VQDEF1 = "vqdef1";
	public static final String VQDEF2 = "vqdef2";
	public static final String VQDEF3 = "vqdef3";
	public static final String VQDEF4 = "vqdef4";
	public static final String VQDEF5 = "vqdef5";
	public static final String VQDEF6 = "vqdef6";
	public static final String VQDEF7 = "vqdef7";
	public static final String VQDEF8 = "vqdef8";
	public static final String VQDEF9 = "vqdef9";
	public static final String VQDEF10 = "vqdef10";
	public static final String VQDEF11 = "vqdef11";
	public static final String VQDEF12 = "vqdef12";
	public static final String VQDEF13 = "vqdef13";
	public static final String VQDEF14 = "vqdef14";
	public static final String VQDEF15 = "vqdef15";
	public static final String VQDEF16 = "vqdef16";
	public static final String VQDEF17 = "vqdef17";
	public static final String VQDEF18 = "vqdef18";
	public static final String VQDEF19 = "vqdef19";
	public static final String VQDEF20 = "vqdef20";
	public static final String DR = "dr";
	public static final String TS = "ts";
	public static final String PK_OPREP_B = "pk_oprep_b";


	public String getPk_oprep_qc() {
		return pk_oprep_qc;
	}

	public void setPk_oprep_qc(String pk_oprep_qc) {
		this.pk_oprep_qc = pk_oprep_qc;
	}

	public Integer getFqsrctype() {
		return (Integer)getAttributeValue("fqsrctype");
	}

	public void setFqsrctype(Integer fqsrctype) {
		setAttributeValue("fqsrctype",fqsrctype);
	}

	public Integer getFqprocessmethod() {
		return (Integer)getAttributeValue("fqprocessmethod");
	}

	public void setFqprocessmethod(Integer fqprocessmethod) {
		setAttributeValue("fqprocessmethod",fqprocessmethod);
	}

	public UFBoolean getBqhaswr() {
		return bqhaswr;
	}

	public void setBqhaswr(UFBoolean bqhaswr) {
		this.bqhaswr = bqhaswr;
	}

	public String getCqqcorgid() {
		return cqqcorgid;
	}

	public void setCqqcorgid(String cqqcorgid) {
		this.cqqcorgid = cqqcorgid;
	}

	public String getCqqcorgvid() {
		return cqqcorgvid;
	}

	public void setCqqcorgvid(String cqqcorgvid) {
		this.cqqcorgvid = cqqcorgvid;
	}

	public String getCqqcid() {
		return cqqcid;
	}

	public void setCqqcid(String cqqcid) {
		this.cqqcid = cqqcid;
	}

	public String getCqqcbid() {
		return cqqcbid;
	}

	public void setCqqcbid(String cqqcbid) {
		this.cqqcbid = cqqcbid;
	}

	public String getVqqcbillcode() {
		return vqqcbillcode;
	}

	public void setVqqcbillcode(String vqqcbillcode) {
		this.vqqcbillcode = vqqcbillcode;
	}

	public String getVqqcrowno() {
		return vqqcrowno;
	}

	public void setVqqcrowno(String vqqcrowno) {
		this.vqqcrowno = vqqcrowno;
	}

	public String getFqdefecttype() {
		return fqdefecttype;
	}

	public void setFqdefecttype(String fqdefecttype) {
		this.fqdefecttype = fqdefecttype;
	}

	public String getVqdefectnote() {
		return vqdefectnote;
	}

	public void setVqdefectnote(String vqdefectnote) {
		this.vqdefectnote = vqdefectnote;
	}

	public String getCqchargepsnid() {
		return cqchargepsnid;
	}

	public void setCqchargepsnid(String cqchargepsnid) {
		this.cqchargepsnid = cqchargepsnid;
	}

	public String getCqchargedeptid() {
		return cqchargedeptid;
	}

	public void setCqchargedeptid(String cqchargedeptid) {
		this.cqchargedeptid = cqchargedeptid;
	}

	public String getCqchargedeptvid() {
		return cqchargedeptvid;
	}

	public void setCqchargedeptvid(String cqchargedeptvid) {
		this.cqchargedeptvid = cqchargedeptvid;
	}

	public UFDouble getNqastnum() {
		return (UFDouble) getAttributeValue("nqastnum");

	}

	public void setNqastnum(UFDouble nqastnum) {
		setAttributeValue("nqastnum",nqastnum);
	}

	public UFDouble getNqnum() {
		return (UFDouble)getAttributeValue("nqnum");
	}

	public void setNqnum(UFDouble nqnum) {
		setAttributeValue("nqnum",nqnum);
	}

	public UFDouble getNqasttransfernum() {
		return nqasttransfernum;
	}

	public void setNqasttransfernum(UFDouble nqasttransfernum) {
		this.nqasttransfernum = nqasttransfernum;
	}

	public UFDouble getNqtransfernum() {
		return nqtransfernum;
	}

	public void setNqtransfernum(UFDouble nqtransfernum) {
		this.nqtransfernum = nqtransfernum;
	}

	public UFDouble getNqastreworkmonum() {
		return nqastreworkmonum;
	}

	public void setNqastreworkmonum(UFDouble nqastreworkmonum) {
		this.nqastreworkmonum = nqastreworkmonum;
	}

	public UFDouble getNqreworkmonum() {
		return nqreworkmonum;
	}

	public void setNqreworkmonum(UFDouble nqreworkmonum) {
		this.nqreworkmonum = nqreworkmonum;
	}

	public String getVqdef1() {
		return vqdef1;
	}

	public void setVqdef1(String vqdef1) {
		this.vqdef1 = vqdef1;
	}

	public String getVqdef2() {
		return vqdef2;
	}

	public void setVqdef2(String vqdef2) {
		this.vqdef2 = vqdef2;
	}

	public String getVqdef3() {
		return vqdef3;
	}

	public void setVqdef3(String vqdef3) {
		this.vqdef3 = vqdef3;
	}

	public String getVqdef4() {
		return vqdef4;
	}

	public void setVqdef4(String vqdef4) {
		this.vqdef4 = vqdef4;
	}

	public String getVqdef5() {
		return vqdef5;
	}

	public void setVqdef5(String vqdef5) {
		this.vqdef5 = vqdef5;
	}

	public String getVqdef6() {
		return vqdef6;
	}

	public void setVqdef6(String vqdef6) {
		this.vqdef6 = vqdef6;
	}

	public String getVqdef7() {
		return vqdef7;
	}

	public void setVqdef7(String vqdef7) {
		this.vqdef7 = vqdef7;
	}

	public String getVqdef8() {
		return vqdef8;
	}

	public void setVqdef8(String vqdef8) {
		this.vqdef8 = vqdef8;
	}

	public String getVqdef9() {
		return vqdef9;
	}

	public void setVqdef9(String vqdef9) {
		this.vqdef9 = vqdef9;
	}

	public String getVqdef10() {
		return vqdef10;
	}

	public void setVqdef10(String vqdef10) {
		this.vqdef10 = vqdef10;
	}

	public String getVqdef11() {
		return vqdef11;
	}

	public void setVqdef11(String vqdef11) {
		this.vqdef11 = vqdef11;
	}

	public String getVqdef12() {
		return vqdef12;
	}

	public void setVqdef12(String vqdef12) {
		this.vqdef12 = vqdef12;
	}

	public String getVqdef13() {
		return vqdef13;
	}

	public void setVqdef13(String vqdef13) {
		this.vqdef13 = vqdef13;
	}

	public String getVqdef14() {
		return vqdef14;
	}

	public void setVqdef14(String vqdef14) {
		this.vqdef14 = vqdef14;
	}

	public String getVqdef15() {
		return vqdef15;
	}

	public void setVqdef15(String vqdef15) {
		this.vqdef15 = vqdef15;
	}

	public String getVqdef16() {
		return vqdef16;
	}

	public void setVqdef16(String vqdef16) {
		this.vqdef16 = vqdef16;
	}

	public String getVqdef17() {
		return vqdef17;
	}

	public void setVqdef17(String vqdef17) {
		this.vqdef17 = vqdef17;
	}

	public String getVqdef18() {
		return vqdef18;
	}

	public void setVqdef18(String vqdef18) {
		this.vqdef18 = vqdef18;
	}

	public String getVqdef19() {
		return vqdef19;
	}

	public void setVqdef19(String vqdef19) {
		this.vqdef19 = vqdef19;
	}

	public String getVqdef20() {
		return vqdef20;
	}

	public void setVqdef20(String vqdef20) {
		this.vqdef20 = vqdef20;
	}

	/**
	 * ����name��Setter����.��������dr
	 * ��������:2026-07-06
	 * @ param newName java.lang.Integer
	 */
	public void setDr(java.lang.Integer dr){
		this.dr = dr;
	}
	/**
	 * ����name��Getter����.��������dr
	 * ��������:2026-07-06
	 * @return java.lang.Integer
	 */
	public java.lang.Integer getDr(){
		return this.dr;
	}
	
	/**
	 * ����name��Setter����.��������ts
	 * ��������:2026-07-06
	 * @ param newName nc.vo.pub.lang.UFDateTime
	 */
	public void setTs(nc.vo.pub.lang.UFDateTime ts){
		this.ts = ts;
	}
	/**
	 * ����name��Getter����.��������ts
	 * ��������:2026-07-06
	 * @return nc.vo.pub.lang.UFDateTime
	 */
	public nc.vo.pub.lang.UFDateTime getTs(){
		return this.ts;
	}
	
	
	/**
	 * ����name��Setter����.��������pk_oprep_b
	 * ��������:2026-07-06
	 * @ param newName java.lang.String
	 */
	public void setPk_oprep_b(java.lang.String pk_oprep_b){
		this.pk_oprep_b = pk_oprep_b;
	}
	/**
	 * ����name��Getter����.��������pk_oprep_b
	 * ��������:2026-07-06
	 * @return java.lang.String
	 */
	public java.lang.String getPk_oprep_b(){
		return this.pk_oprep_b;
	}
	
	
	public java.lang.String getParentPKFieldName() {
	    return "pk_oprep_b";
	}   
    
	@Override
	public java.lang.String getPKFieldName() {
	  return "pk_oprep_qc";
	}
    
	/**
	 * <p>���ر�����.
	 * <p>
	 * ��������:
	 * @return java.lang.String
	 */
	@Override
	public java.lang.String getTableName() {
		return "mm_operationrep_qc";
	}
	
	public static java.lang.String getDefaultTableName() {
		return "mm_operationrep_qc";
	}    
    
	@Override
	@nc.vo.annotation.MDEntityInfo(beanFullclassName =  "nc.vo.mmsfc.operationrep.entity.OprepQcVO" )
	public IVOMeta getMetaData() {
		return VOMetaFactory.getInstance().getVOMeta("mmsfc.mm_operationrep_qc");
  	}
  	
}
