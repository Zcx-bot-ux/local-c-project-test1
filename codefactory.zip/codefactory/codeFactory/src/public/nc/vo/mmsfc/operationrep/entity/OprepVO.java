package nc.vo.mmsfc.operationrep.entity;


import nc.vo.pub.IVOMeta;
import nc.vo.pub.SuperVO;
import nc.vo.pub.lang.UFDate;
import nc.vo.pub.lang.UFDateTime;
import nc.vo.pubapp.pattern.model.meta.entity.vo.VOMetaFactory;

public class OprepVO extends SuperVO {

	//??????
	public OprepVO() {
		super();
	}


    private transient java.lang.String pk_oprep;
    private transient java.lang.String pk_group;
    private transient java.lang.String pk_org;
    private transient java.lang.String pk_org_v;
    private transient java.lang.String ctrantypeid;
    private transient java.lang.String vtrantypecode;
    private transient java.lang.String vbillcode;
    private transient nc.vo.pub.lang.UFDate dbilldate;
    private transient java.lang.Integer fstatusflag;
    private transient java.lang.String cwkid;
    private transient java.lang.String cdeptid;
    private transient java.lang.String cdeptvid;
    private transient java.lang.String cshiftid;
    private transient java.lang.String cteamid;
    private transient java.lang.Integer fprodmode;
    private transient java.lang.String billmaker;
    private transient nc.vo.pub.lang.UFDate dmakedate;
    private transient java.lang.String creator;
    private transient nc.vo.pub.lang.UFDateTime creationtime;
    private transient java.lang.String approver;
    private transient nc.vo.pub.lang.UFDate taudittime;
    private transient java.lang.String modifier;
    private transient nc.vo.pub.lang.UFDateTime modifiedtime;
    private transient java.lang.String vdef1;
    private transient java.lang.String vdef2;
    private transient java.lang.String vdef3;
    private transient java.lang.String vdef4;
    private transient java.lang.String vdef5;
    private transient java.lang.String vdef6;
    private transient java.lang.String vdef7;
    private transient java.lang.String vdef8;
    private transient java.lang.String vdef9;
    private transient java.lang.String vdef10;
    private transient java.lang.String vdef11;
    private transient java.lang.String vdef12;
    private transient java.lang.String vdef13;
    private transient java.lang.String vdef14;
    private transient java.lang.String vdef15;
    private transient java.lang.String vdef16;
    private transient java.lang.String vdef17;
    private transient java.lang.String vdef18;
    private transient java.lang.String vdef19;
    private transient java.lang.String vdef20;
    private transient java.lang.Integer saga_frozen;
    private transient java.lang.String saga_gtxid;
    private transient java.lang.String saga_btxid;
    private transient java.lang.Integer saga_status;
	private java.lang.Integer dr = 0;
    private transient nc.vo.pub.lang.UFDateTime ts;


	public static final String PK_OPREP = "pk_oprep";
	public static final String PK_GROUP = "pk_group";
	public static final String PK_ORG = "pk_org";
	public static final String PK_ORG_V = "pk_org_v";
	public static final String CTRANTYPEID = "ctrantypeid";
	public static final String VTRANTYPECODE = "vtrantypecode";
	public static final String VBILLCODE = "vbillcode";
	public static final String DBILLDATE = "dbilldate";
	public static final String FSTATUSFLAG = "fstatusflag";
	public static final String CWKID = "cwkid";
	public static final String CDEPTID = "cdeptid";
	public static final String CDEPTVID = "cdeptvid";
	public static final String CSHIFTID = "cshiftid";
	public static final String CTEAMID = "cteamid";
	public static final String FPRODMODE = "fprodmode";
	public static final String BILLMAKER = "billmaker";
	public static final String DMAKEDATE = "dmakedate";
	public static final String CREATOR = "creator";
	public static final String CREATIONTIME = "creationtime";
	public static final String APPROVER = "approver";
	public static final String TAUDITTIME = "taudittime";
	public static final String MODIFIER = "modifier";
	public static final String MODIFIEDTIME = "modifiedtime";
	public static final String VDEF1 = "vdef1";
	public static final String VDEF2 = "vdef2";
	public static final String VDEF3 = "vdef3";
	public static final String VDEF4 = "vdef4";
	public static final String VDEF5 = "vdef5";
	public static final String VDEF6 = "vdef6";
	public static final String VDEF7 = "vdef7";
	public static final String VDEF8 = "vdef8";
	public static final String VDEF9 = "vdef9";
	public static final String VDEF10 = "vdef10";
	public static final String VDEF11 = "vdef11";
	public static final String VDEF12 = "vdef12";
	public static final String VDEF13 = "vdef13";
	public static final String VDEF14 = "vdef14";
	public static final String VDEF15 = "vdef15";
	public static final String VDEF16 = "vdef16";
	public static final String VDEF17 = "vdef17";
	public static final String VDEF18 = "vdef18";
	public static final String VDEF19 = "vdef19";
	public static final String VDEF20 = "vdef20";
	public static final String SAGA_FROZEN = "saga_frozen";
	public static final String SAGA_GTXID = "saga_gtxid";
	public static final String SAGA_BTXID = "saga_btxid";
	public static final String SAGA_STATUS = "saga_status";
	public static final String DR = "dr";
	public static final String TS = "ts";

	//����
	public String getPk_oprep() {
		return (String) getAttributeValue("pk_oprep");
	}

	public void setPk_oprep(String pk_oprep) {
		setAttributeValue("pk_oprep",pk_oprep);
	}

	public Integer getFstatusflag() {
		return (Integer) getAttributeValue("fstatusflag");
	}

	public void setFstatusflag(Integer fstatusflag) {
		setAttributeValue("fstatusflag", fstatusflag);
	}

	public UFDate getDmakedate() {
		return (UFDate) getAttributeValue("dmakedate");
	}

	public void setDmakedate(UFDate dmakedate) {
		setAttributeValue("dmakedate",dmakedate);
	}

	public String getApprover() {
		return (String) getAttributeValue("approver");
	}

	public void setApprover(String approver) {
		setAttributeValue("approver", approver);
	}

	public String getBillmaker() {
		return (String)getAttributeValue("billmaker");
	}

	public void setBillmaker(String billmaker) {
		setAttributeValue("billmaker",billmaker);
	}

	/**
	 * ????name??Setter????.????????dr
	 * ????????:2026-07-06
	 * @ param newName java.lang.Integer
	 */
	public void setDr(java.lang.Integer dr){
		setAttributeValue("dr",dr);
	}
	/**
	 * ????name??Getter????.????????dr
	 * ????????:2026-07-06
	 * @return java.lang.Integer
	 */
	public java.lang.Integer getDr(){
		return (Integer) getAttributeValue("dr");
	}

	/**
	 * ????name??Setter????.????????ts
	 * ????????:2026-07-06
	 * @ param newName nc.vo.pub.lang.UFDateTime
	 */
	public void setTs(nc.vo.pub.lang.UFDateTime ts){
		setAttributeValue("ts",ts);
	}
	/**
	 * ????name??Getter????.????????ts
	 * ????????:2026-07-06
	 * @return nc.vo.pub.lang.UFDateTime
	 */
	public nc.vo.pub.lang.UFDateTime getTs(){
		return (nc.vo.pub.lang.UFDateTime)getAttributeValue("ts");
	}

	public String getPk_group() {
		return (String)getAttributeValue("pk_group");
	}

	public void setPk_group(String pk_group) {
		setAttributeValue("pk_group",pk_group);
	}

	public String getPk_org() {
		return (String)getAttributeValue("pk_org");
	}

	public void setPk_org(String pk_org) {
		setAttributeValue("pk_org",pk_org);
	}

	public String getPk_org_v() {
		return (String) getAttributeValue("pk_org_v");
	}

	public void setPk_org_v(String pk_org_v) {
		setAttributeValue("pk_org_v",pk_org_v);
	}

	public String getCtrantypeid() {
		return (String)getAttributeValue("ctrantypeid");
	}

	public void setCtrantypeid(String ctrantypeid) {
		setAttributeValue("ctrantypeid",ctrantypeid);
	}

	public String getVtrantypecode() {
		return (String)getAttributeValue(vtrantypecode);
	}

	public void setVtrantypecode(String vtrantypecode) {
		setAttributeValue("vtrantypecode",vtrantypecode);
	}

	public String getVbillcode() {
		return vbillcode;
	}

	public void setVbillcode(String vbillcode) {
		this.vbillcode = vbillcode;
	}

	public UFDate getDbilldate() {
		return dbilldate;
	}

	public void setDbilldate(UFDate dbilldate) {
		this.dbilldate = dbilldate;
	}

	public String getCwkid() {
		return cwkid;
	}

	public void setCwkid(String cwkid) {
		this.cwkid = cwkid;
	}

	public String getCdeptid() {
		return (String)getAttributeValue("cdeptid");
	}

	public void setCdeptid(String cdeptid) {
		setAttributeValue("cdeptid",cdeptid);
	}

	public String getCdeptvid() {
		return (String)getAttributeValue("cdeptvid");
	}

	public void setCdeptvid(String cdeptvid) {
		setAttributeValue("cdeptvid",cdeptvid);
	}

	public String getCshiftid() {
		return cshiftid;
	}

	public void setCshiftid(String cshiftid) {
		this.cshiftid = cshiftid;
	}

	public String getCteamid() {
		return cteamid;
	}

	public void setCteamid(String cteamid) {
		this.cteamid = cteamid;
	}

	public Integer getFprodmode() {
		return fprodmode;
	}

	public void setFprodmode(Integer fprodmode) {
		this.fprodmode = fprodmode;
	}

	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public UFDateTime getCreationtime() {
		return creationtime;
	}

	public void setCreationtime(UFDateTime creationtime) {
		this.creationtime = creationtime;
	}

	public UFDate getTaudittime() {
		return taudittime;
	}

	public void setTaudittime(UFDate taudittime) {
		this.taudittime = taudittime;
	}

	public String getModifier() {
		return modifier;
	}

	public void setModifier(String modifier) {
		this.modifier = modifier;
	}

	public UFDateTime getModifiedtime() {
		return modifiedtime;
	}

	public void setModifiedtime(UFDateTime modifiedtime) {
		this.modifiedtime = modifiedtime;
	}

	public String getVdef1() {
		return vdef1;
	}

	public void setVdef1(String vdef1) {
		this.vdef1 = vdef1;
	}

	public String getVdef2() {
		return vdef2;
	}

	public void setVdef2(String vdef2) {
		this.vdef2 = vdef2;
	}

	public String getVdef3() {
		return vdef3;
	}

	public void setVdef3(String vdef3) {
		this.vdef3 = vdef3;
	}

	public String getVdef4() {
		return vdef4;
	}

	public void setVdef4(String vdef4) {
		this.vdef4 = vdef4;
	}

	public String getVdef5() {
		return vdef5;
	}

	public void setVdef5(String vdef5) {
		this.vdef5 = vdef5;
	}

	public String getVdef6() {
		return vdef6;
	}

	public void setVdef6(String vdef6) {
		this.vdef6 = vdef6;
	}

	public String getVdef7() {
		return vdef7;
	}

	public void setVdef7(String vdef7) {
		this.vdef7 = vdef7;
	}

	public String getVdef8() {
		return vdef8;
	}

	public void setVdef8(String vdef8) {
		this.vdef8 = vdef8;
	}

	public String getVdef9() {
		return vdef9;
	}

	public void setVdef9(String vdef9) {
		this.vdef9 = vdef9;
	}

	public String getVdef10() {
		return vdef10;
	}

	public void setVdef10(String vdef10) {
		this.vdef10 = vdef10;
	}

	public String getVdef11() {
		return vdef11;
	}

	public void setVdef11(String vdef11) {
		this.vdef11 = vdef11;
	}

	public String getVdef12() {
		return vdef12;
	}

	public void setVdef12(String vdef12) {
		this.vdef12 = vdef12;
	}

	public String getVdef13() {
		return vdef13;
	}

	public void setVdef13(String vdef13) {
		this.vdef13 = vdef13;
	}

	public String getVdef14() {
		return vdef14;
	}

	public void setVdef14(String vdef14) {
		this.vdef14 = vdef14;
	}

	public String getVdef15() {
		return vdef15;
	}

	public void setVdef15(String vdef15) {
		this.vdef15 = vdef15;
	}

	public String getVdef16() {
		return vdef16;
	}

	public void setVdef16(String vdef16) {
		this.vdef16 = vdef16;
	}

	public String getVdef17() {
		return vdef17;
	}

	public void setVdef17(String vdef17) {
		this.vdef17 = vdef17;
	}

	public String getVdef18() {
		return vdef18;
	}

	public void setVdef18(String vdef18) {
		this.vdef18 = vdef18;
	}

	public String getVdef19() {
		return vdef19;
	}

	public void setVdef19(String vdef19) {
		this.vdef19 = vdef19;
	}

	public String getVdef20() {
		return vdef20;
	}

	public void setVdef20(String vdef20) {
		this.vdef20 = vdef20;
	}

	public Integer getSaga_frozen() {
		return saga_frozen;
	}

	public void setSaga_frozen(Integer saga_frozen) {
		this.saga_frozen = saga_frozen;
	}

	public String getSaga_gtxid() {
		return saga_gtxid;
	}

	public void setSaga_gtxid(String saga_gtxid) {
		this.saga_gtxid = saga_gtxid;
	}

	public String getSaga_btxid() {
		return saga_btxid;
	}

	public void setSaga_btxid(String saga_btxid) {
		this.saga_btxid = saga_btxid;
	}

	public Integer getSaga_status() {
		return saga_status;
	}

	public void setSaga_status(Integer saga_status) {
		this.saga_status = saga_status;
	}

	public java.lang.String getParentPKFieldName() {
	    return null;
	}   
    
	@Override
	public java.lang.String getPKFieldName() {
	  return "pk_oprep";
	}
    
	/**
	 * <p>?????????.
	 * <p>
	 * ????????:
	 * @return java.lang.String
	 */
	@Override
	public java.lang.String getTableName() {
		return "mm_operationrep";
	}
	
	public static java.lang.String getDefaultTableName() {
		return "mm_operationrep";
	}    
    
	@Override
	@nc.vo.annotation.MDEntityInfo(beanFullclassName =  "nc.vo.mmsfc.operationrep.entity.OprepVO" )
	public IVOMeta getMetaData() {
		return VOMetaFactory.getInstance().getVOMeta("mmsfc.mm_operationrep");
  	}
  	
}
