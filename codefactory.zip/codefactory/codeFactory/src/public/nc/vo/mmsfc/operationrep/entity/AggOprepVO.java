package nc.vo.mmsfc.operationrep.entity;

import nc.vo.pub.AggregatedValueObject;
import nc.vo.pub.CircularlyAccessibleValueObject;
import nc.vo.pubapp.pattern.model.entity.bill.AbstractBill;
import nc.vo.pubapp.pattern.model.meta.entity.bill.BillMetaFactory;
import nc.vo.pubapp.pattern.model.meta.entity.bill.IBillMeta;


/**
 * 
 * ���ӱ�/����ͷ/������ۺ�VO
 *
 * @author 
 * @version NCPrj ??
 */
@nc.vo.annotation.AggVoInfo(parentVO = "nc.vo.mmsfc.operationrep.entity.OprepVO")
public class  AggOprepVO  extends AbstractBill {
	private static final long serialVersionUID = 1309613813878961316L;

	@Override
	public IBillMeta getMetaData() {
		return BillMetaFactory.getInstance().getBillMeta(AggOprepVOMeta.class);
	}

	// ��ͷ
	public OprepVO getParentVO() {
		return (OprepVO) this.getParent();
	}
	public void setParentVO(OprepVO parent) {
		this.setParent(parent);
	}

	// �ӱ� 1����ϸ
	public OprepItemVO[] getItemVO() {
		return (OprepItemVO[]) this.getChildren(OprepItemVO.class);
	}
	public void setItemVO(OprepItemVO[] items) {
		this.setChildren(OprepItemVO.class, items);
	}

	// �ӱ� 2���Ų�����
	public ProoorderVO[] getProoorderVO() {
		return (ProoorderVO[]) this.getChildren(ProoorderVO.class);
	}
	public void setProoorderVO(ProoorderVO[] items) {
		this.setChildren(ProoorderVO.class, items);
	}


//	// �� getChildrenVO() ���� OprepItemVO[]�������޲ΰ汾��
//	@Override
//	public OprepItemVO[] getChildrenVO() {
//		OprepItemVO[] items = this.getItemVO();
//		return items != null ? items : new OprepItemVO[0];   // �������� null
//
//	}
//	@Override
//	public void setChildrenVO(nc.vo.pub.CircularlyAccessibleValueObject[] children) {
//		this.setItemVO((OprepItemVO[]) children);
//	}
	@Override
	public OprepItemVO[] getChildrenVO() {
		return this.getItemVO();
	}
	@Override
	public void setChildrenVO(CircularlyAccessibleValueObject[] children) {
		if (children == null || children.length == 0) {
			this.setItemVO(new OprepItemVO[0]);
			return;
		}
		// ��ȫ��飺ֻ������� OprepItemVO[] ������
		if (children instanceof OprepItemVO[]) {
			this.setItemVO((OprepItemVO[]) children);
		} else if (children[0] instanceof OprepItemVO) {
			OprepItemVO[] items = new OprepItemVO[children.length];
			System.arraycopy(children, 0, items, 0, children.length);
			this.setItemVO(items);
		}
		// �������͵��ӱ����ݲ������ﴦ�����ÿ���� setChildren(Class, [])��
	}

}
