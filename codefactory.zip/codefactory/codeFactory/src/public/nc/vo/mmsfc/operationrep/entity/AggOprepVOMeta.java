package nc.vo.mmsfc.operationrep.entity;
import nc.vo.pubapp.pattern.model.meta.entity.bill.AbstractBillMeta;
public class AggOprepVOMeta extends AbstractBillMeta{
	
	public AggOprepVOMeta(){
		this.init();
	}

    private void init() {
        this.setParent(nc.vo.mmsfc.operationrep.entity.OprepVO.class);
        this.addChildren(nc.vo.mmsfc.operationrep.entity.OprepItemVO.class);
        this.addChildren(nc.vo.mmsfc.operationrep.entity.ProoorderVO.class);

    }

}
