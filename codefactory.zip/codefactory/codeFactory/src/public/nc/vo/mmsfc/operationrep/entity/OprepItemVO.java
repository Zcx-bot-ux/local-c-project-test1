package nc.vo.mmsfc.operationrep.entity;


import nc.vo.pub.IVOMeta;
import nc.vo.pub.SuperVO;
import nc.vo.pub.lang.UFBoolean;
import nc.vo.pub.lang.UFDateTime;
import nc.vo.pub.lang.UFDouble;
import nc.vo.pubapp.pattern.model.meta.entity.vo.VOMetaFactory;

public class OprepItemVO extends SuperVO {

	//���췽��
	public OprepItemVO() {
		super();
	}


    private java.lang.String pk_oprep_b;
    private java.lang.String vrowno;
    private java.lang.String pk_group;
    private java.lang.String pk_org;
    private java.lang.String pk_org_v;
    private java.lang.String cmoid;
    private java.lang.String vmobillcode;
    private java.lang.String vmobilltype;
    private java.lang.String vmotrantypeid;
    private java.lang.String vmotrantypecode;
    private java.lang.String cmooutputid;
    private java.lang.String vmooutputrowno;
    private java.lang.String cmoprocedureid;
    private java.lang.String vmoprocedurerowno;
    private java.lang.String cbmaterialid;
    private java.lang.String cbmaterialvid;
    private java.lang.String vbchangerate;
    private java.lang.String cbunitid;
    private java.lang.String cbastunitid;
    private java.lang.String cbcustomerid;
    private java.lang.String cbcustomervid;
    private java.lang.String cbprojectid;
    private java.lang.String cbproductorid;
    private java.lang.String cbvendorid;
    private java.lang.String cbvendorvid;
    private java.lang.String cbcustmaterialid;
    private java.lang.String cffileid;
    private java.lang.String vbfree1;
    private java.lang.String vbfree2;
    private java.lang.String vbfree3;
    private java.lang.String vbfree4;
    private java.lang.String vbfree5;
    private java.lang.String vbfree6;
    private java.lang.String vbfree7;
    private java.lang.String vbfree8;
    private java.lang.String vbfree9;
    private java.lang.String vbfree10;
    private java.lang.String vboperationno;
    private java.lang.String cboperationtypeid;
    private java.lang.String cbwkid;
    private java.lang.String cbdeptid;
    private java.lang.String cbdeptvid;
    private java.lang.String cbshiftid;
    private java.lang.String cbteamid;
    private java.lang.String cbworkman;
    private nc.vo.pub.lang.UFDouble nboprepnum;
    private nc.vo.pub.lang.UFDouble nbastoprepnum;
    private nc.vo.pub.lang.UFDouble nbqualitynum;
    private nc.vo.pub.lang.UFDouble nbastqualitynum;
    private nc.vo.pub.lang.UFDouble nbreworknum;
    private nc.vo.pub.lang.UFDouble nbastreworknum;
    private nc.vo.pub.lang.UFDouble nbrejectnum;
    private nc.vo.pub.lang.UFDouble nbastrejectnum;
    private nc.vo.pub.lang.UFDouble nbtransfernum;
    private nc.vo.pub.lang.UFDouble nbasttransfernum;
    private nc.vo.pub.lang.UFDouble nbreworkmonum;
    private nc.vo.pub.lang.UFDouble nbastreworkmonum;
    private nc.vo.pub.lang.UFBoolean bbcheckpoint;
    private nc.vo.pub.lang.UFBoolean bbreppoint;
    private nc.vo.pub.lang.UFDouble nbastapplychecknum;
    private nc.vo.pub.lang.UFDouble nbapplychecknum;
    private nc.vo.pub.lang.UFDouble nbastapplycheckednum;
    private nc.vo.pub.lang.UFDouble nbapplycheckednum;
    private nc.vo.pub.lang.UFDouble nbonenum;
    private nc.vo.pub.lang.UFDouble nbastonenum;
    private nc.vo.pub.lang.UFDateTime tbactbegintime;
    private nc.vo.pub.lang.UFDateTime tbactendtime;
    private java.lang.String vbbatchid;
    private java.lang.String vbbatchcode;
    private java.lang.String cbfirstmoid;
    private java.lang.String vbfirstmocode;
    private java.lang.Integer fbtransfertype;
    private java.lang.Integer fbbackflushstate;
    private nc.vo.pub.lang.UFBoolean bbbackflush;
    private nc.vo.pub.lang.UFBoolean bbconsume;
    private java.lang.String vfirstid;
    private java.lang.String vfirstbid;
    private java.lang.String vfirsttype;
    private java.lang.String vfirstcode;
    private java.lang.String vfirsttranstypeid;
    private java.lang.String vfirsttranstypecode;
    private java.lang.String vfirstrowno;
    private java.lang.String vsrcid;
    private java.lang.String vsrcbid;
    private java.lang.String vsrctype;
    private java.lang.String vsrccode;
    private java.lang.String vsrctranstypeid;
    private java.lang.String vsrctranstypecode;
    private java.lang.String vsrcrowno;
    private nc.vo.pub.lang.UFDateTime tsrcts;
    private java.lang.String vbdef1;
    private java.lang.String vbdef2;
    private java.lang.String vbdef3;
    private java.lang.String vbdef4;
    private java.lang.String vbdef5;
    private java.lang.String vbdef6;
    private java.lang.String vbdef7;
    private java.lang.String vbdef8;
    private java.lang.String vbdef9;
    private java.lang.String vbdef10;
    private java.lang.String vbdef11;
    private java.lang.String vbdef12;
    private java.lang.String vbdef13;
    private java.lang.String vbdef14;
    private java.lang.String vbdef15;
    private java.lang.String vbdef16;
    private java.lang.String vbdef17;
    private java.lang.String vbdef18;
    private java.lang.String vbdef19;
    private java.lang.String vbdef20;
    private java.lang.String vbnote;
    private nc.vo.mmsfc.operationrep.entity.OprepQcVO[] pk_oprep_qc;
    private java.lang.String cbqid;
    private java.lang.Integer fbqsrctype;
    private java.lang.Integer fbqprocessmethod;
    private nc.vo.pub.lang.UFBoolean bbqhaswr;
    private java.lang.String cbqqcid;
    private java.lang.String cbqqcbid;
    private java.lang.String cbqqcorgid;
    private java.lang.String cbqqcorgvid;
    private java.lang.String vbqqcbillcode;
    private java.lang.String vbqqcrowno;
    private java.lang.String fbqdefecttype;
    private java.lang.String vbqdefectnote;
    private java.lang.String cbqchargepsnid;
    private java.lang.String cbqchargedeptid;
    private java.lang.String cbqchargedeptvid;
    private nc.vo.pub.lang.UFDouble nbqastnum;
    private nc.vo.pub.lang.UFDouble nbqnum;
    private nc.vo.pub.lang.UFDouble nbqasttransfernum;
    private nc.vo.pub.lang.UFDouble nbqtransfernum;
    private nc.vo.pub.lang.UFDouble nbqastreworkmonum;
    private nc.vo.pub.lang.UFDouble nbqreworkmonum;
    private nc.vo.pub.lang.UFDateTime tbqts;
    private java.lang.String vbqdef1;
    private java.lang.String vbqdef2;
    private java.lang.String vbqdef3;
    private java.lang.String vbqdef4;
    private java.lang.String vbqdef5;
    private java.lang.String vbqdef6;
    private java.lang.String vbqdef7;
    private java.lang.String vbqdef8;
    private java.lang.String vbqdef9;
    private java.lang.String vbqdef10;
    private java.lang.String vbqdef11;
    private java.lang.String vbqdef12;
    private java.lang.String vbqdef13;
    private java.lang.String vbqdef14;
    private java.lang.String vbqdef15;
    private java.lang.String vbqdef16;
    private java.lang.String vbqdef17;
    private java.lang.String vbqdef18;
    private java.lang.String vbqdef19;
    private java.lang.String vbqdef20;
	private java.lang.Integer dr = 0;
    private nc.vo.pub.lang.UFDateTime ts;
    private java.lang.String pk_oprep;


	public static final String PK_OPREP_B = "pk_oprep_b";
	public static final String VROWNO = "vrowno";
	public static final String PK_GROUP = "pk_group";
	public static final String PK_ORG = "pk_org";
	public static final String PK_ORG_V = "pk_org_v";
	public static final String CMOID = "cmoid";
	public static final String VMOBILLCODE = "vmobillcode";
	public static final String VMOBILLTYPE = "vmobilltype";
	public static final String VMOTRANTYPEID = "vmotrantypeid";
	public static final String VMOTRANTYPECODE = "vmotrantypecode";
	public static final String CMOOUTPUTID = "cmooutputid";
	public static final String VMOOUTPUTROWNO = "vmooutputrowno";
	public static final String CMOPROCEDUREID = "cmoprocedureid";
	public static final String VMOPROCEDUREROWNO = "vmoprocedurerowno";
	public static final String CBMATERIALID = "cbmaterialid";
	public static final String CBMATERIALVID = "cbmaterialvid";
	public static final String VBCHANGERATE = "vbchangerate";
	public static final String CBUNITID = "cbunitid";
	public static final String CBASTUNITID = "cbastunitid";
	public static final String CBCUSTOMERID = "cbcustomerid";
	public static final String CBCUSTOMERVID = "cbcustomervid";
	public static final String CBPROJECTID = "cbprojectid";
	public static final String CBPRODUCTORID = "cbproductorid";
	public static final String CBVENDORID = "cbvendorid";
	public static final String CBVENDORVID = "cbvendorvid";
	public static final String CBCUSTMATERIALID = "cbcustmaterialid";
	public static final String CFFILEID = "cffileid";
	public static final String VBFREE1 = "vbfree1";
	public static final String VBFREE2 = "vbfree2";
	public static final String VBFREE3 = "vbfree3";
	public static final String VBFREE4 = "vbfree4";
	public static final String VBFREE5 = "vbfree5";
	public static final String VBFREE6 = "vbfree6";
	public static final String VBFREE7 = "vbfree7";
	public static final String VBFREE8 = "vbfree8";
	public static final String VBFREE9 = "vbfree9";
	public static final String VBFREE10 = "vbfree10";
	public static final String VBOPERATIONNO = "vboperationno";
	public static final String CBOPERATIONTYPEID = "cboperationtypeid";
	public static final String CBWKID = "cbwkid";
	public static final String CBDEPTID = "cbdeptid";
	public static final String CBDEPTVID = "cbdeptvid";
	public static final String CBSHIFTID = "cbshiftid";
	public static final String CBTEAMID = "cbteamid";
	public static final String CBWORKMAN = "cbworkman";
	public static final String NBOPREPNUM = "nboprepnum";
	public static final String NBASTOPREPNUM = "nbastoprepnum";
	public static final String NBQUALITYNUM = "nbqualitynum";
	public static final String NBASTQUALITYNUM = "nbastqualitynum";
	public static final String NBREWORKNUM = "nbreworknum";
	public static final String NBASTREWORKNUM = "nbastreworknum";
	public static final String NBREJECTNUM = "nbrejectnum";
	public static final String NBASTREJECTNUM = "nbastrejectnum";
	public static final String NBTRANSFERNUM = "nbtransfernum";
	public static final String NBASTTRANSFERNUM = "nbasttransfernum";
	public static final String NBREWORKMONUM = "nbreworkmonum";
	public static final String NBASTREWORKMONUM = "nbastreworkmonum";
	public static final String BBCHECKPOINT = "bbcheckpoint";
	public static final String BBREPPOINT = "bbreppoint";
	public static final String NBASTAPPLYCHECKNUM = "nbastapplychecknum";
	public static final String NBAPPLYCHECKNUM = "nbapplychecknum";
	public static final String NBASTAPPLYCHECKEDNUM = "nbastapplycheckednum";
	public static final String NBAPPLYCHECKEDNUM = "nbapplycheckednum";
	public static final String NBONENUM = "nbonenum";
	public static final String NBASTONENUM = "nbastonenum";
	public static final String TBACTBEGINTIME = "tbactbegintime";
	public static final String TBACTENDTIME = "tbactendtime";
	public static final String VBBATCHID = "vbbatchid";
	public static final String VBBATCHCODE = "vbbatchcode";
	public static final String CBFIRSTMOID = "cbfirstmoid";
	public static final String VBFIRSTMOCODE = "vbfirstmocode";
	public static final String FBTRANSFERTYPE = "fbtransfertype";
	public static final String FBBACKFLUSHSTATE = "fbbackflushstate";
	public static final String BBBACKFLUSH = "bbbackflush";
	public static final String BBCONSUME = "bbconsume";
	public static final String VFIRSTID = "vfirstid";
	public static final String VFIRSTBID = "vfirstbid";
	public static final String VFIRSTTYPE = "vfirsttype";
	public static final String VFIRSTCODE = "vfirstcode";
	public static final String VFIRSTTRANSTYPEID = "vfirsttranstypeid";
	public static final String VFIRSTTRANSTYPECODE = "vfirsttranstypecode";
	public static final String VFIRSTROWNO = "vfirstrowno";
	public static final String VSRCID = "vsrcid";
	public static final String VSRCBID = "vsrcbid";
	public static final String VSRCTYPE = "vsrctype";
	public static final String VSRCCODE = "vsrccode";
	public static final String VSRCTRANSTYPEID = "vsrctranstypeid";
	public static final String VSRCTRANSTYPECODE = "vsrctranstypecode";
	public static final String VSRCROWNO = "vsrcrowno";
	public static final String TSRCTS = "tsrcts";
	public static final String VBDEF1 = "vbdef1";
	public static final String VBDEF2 = "vbdef2";
	public static final String VBDEF3 = "vbdef3";
	public static final String VBDEF4 = "vbdef4";
	public static final String VBDEF5 = "vbdef5";
	public static final String VBDEF6 = "vbdef6";
	public static final String VBDEF7 = "vbdef7";
	public static final String VBDEF8 = "vbdef8";
	public static final String VBDEF9 = "vbdef9";
	public static final String VBDEF10 = "vbdef10";
	public static final String VBDEF11 = "vbdef11";
	public static final String VBDEF12 = "vbdef12";
	public static final String VBDEF13 = "vbdef13";
	public static final String VBDEF14 = "vbdef14";
	public static final String VBDEF15 = "vbdef15";
	public static final String VBDEF16 = "vbdef16";
	public static final String VBDEF17 = "vbdef17";
	public static final String VBDEF18 = "vbdef18";
	public static final String VBDEF19 = "vbdef19";
	public static final String VBDEF20 = "vbdef20";
	public static final String VBNOTE = "vbnote";
	public static final String PK_OPREP_QC = "pk_oprep_qc";
	public static final String CBQID = "cbqid";
	public static final String FBQSRCTYPE = "fbqsrctype";
	public static final String FBQPROCESSMETHOD = "fbqprocessmethod";
	public static final String BBQHASWR = "bbqhaswr";
	public static final String CBQQCID = "cbqqcid";
	public static final String CBQQCBID = "cbqqcbid";
	public static final String CBQQCORGID = "cbqqcorgid";
	public static final String CBQQCORGVID = "cbqqcorgvid";
	public static final String VBQQCBILLCODE = "vbqqcbillcode";
	public static final String VBQQCROWNO = "vbqqcrowno";
	public static final String FBQDEFECTTYPE = "fbqdefecttype";
	public static final String VBQDEFECTNOTE = "vbqdefectnote";
	public static final String CBQCHARGEPSNID = "cbqchargepsnid";
	public static final String CBQCHARGEDEPTID = "cbqchargedeptid";
	public static final String CBQCHARGEDEPTVID = "cbqchargedeptvid";
	public static final String NBQASTNUM = "nbqastnum";
	public static final String NBQNUM = "nbqnum";
	public static final String NBQASTTRANSFERNUM = "nbqasttransfernum";
	public static final String NBQTRANSFERNUM = "nbqtransfernum";
	public static final String NBQASTREWORKMONUM = "nbqastreworkmonum";
	public static final String NBQREWORKMONUM = "nbqreworkmonum";
	public static final String TBQTS = "tbqts";
	public static final String VBQDEF1 = "vbqdef1";
	public static final String VBQDEF2 = "vbqdef2";
	public static final String VBQDEF3 = "vbqdef3";
	public static final String VBQDEF4 = "vbqdef4";
	public static final String VBQDEF5 = "vbqdef5";
	public static final String VBQDEF6 = "vbqdef6";
	public static final String VBQDEF7 = "vbqdef7";
	public static final String VBQDEF8 = "vbqdef8";
	public static final String VBQDEF9 = "vbqdef9";
	public static final String VBQDEF10 = "vbqdef10";
	public static final String VBQDEF11 = "vbqdef11";
	public static final String VBQDEF12 = "vbqdef12";
	public static final String VBQDEF13 = "vbqdef13";
	public static final String VBQDEF14 = "vbqdef14";
	public static final String VBQDEF15 = "vbqdef15";
	public static final String VBQDEF16 = "vbqdef16";
	public static final String VBQDEF17 = "vbqdef17";
	public static final String VBQDEF18 = "vbqdef18";
	public static final String VBQDEF19 = "vbqdef19";
	public static final String VBQDEF20 = "vbqdef20";
	public static final String DR = "dr";
	public static final String TS = "ts";
	public static final String PK_OPREP = "pk_oprep";

	//����
	public String getPk_oprep_b() {
		return pk_oprep_b;
	}

	public void setPk_oprep_b(String pk_oprep_b) {
		this.pk_oprep_b = pk_oprep_b;
	}


	/**
	 * ����name��Setter����.�������������깤���������ȼ�
	 * ��������:2026-07-06
	 * @ param newName nc.vo.mmsfc.operationrep.entity.OprepQcVO
	 */
	public void setPk_oprep_qc(nc.vo.mmsfc.operationrep.entity.OprepQcVO[] pk_oprep_qc){
		setAttributeValue("pk_oprep_qc",pk_oprep_qc);
	}
	/**
	 * ����name��Getter����.�������������깤���������ȼ�
	 * ��������:2026-07-06
	 * @return nc.vo.mmsfc.operationrep.entity.OprepQcVO
	 */
	public nc.vo.mmsfc.operationrep.entity.OprepQcVO[] getPk_oprep_qc(){
		return (nc.vo.mmsfc.operationrep.entity.OprepQcVO[])getAttributeValue("pk_oprep_qc");
	}

	public String getVrowno() {
		return (String)getAttributeValue("vrowno");
	}

	public void setVrowno(String vrowno) {
		setAttributeValue("vrowno",vrowno);
	}

	public String getPk_group() {
		return pk_group;
	}

	public void setPk_group(String pk_group) {
		this.pk_group = pk_group;
	}

	public String getPk_org() {
		return pk_org;
	}

	public void setPk_org(String pk_org) {
		this.pk_org = pk_org;
	}

	public String getPk_org_v() {
		return pk_org_v;
	}

	public void setPk_org_v(String pk_org_v) {
		this.pk_org_v = pk_org_v;
	}

	public String getCmoid() {
		return cmoid;
	}

	public void setCmoid(String cmoid) {
		this.cmoid = cmoid;
	}

	public String getVmobillcode() {
		return vmobillcode;
	}

	public void setVmobillcode(String vmobillcode) {
		this.vmobillcode = vmobillcode;
	}

	public String getVmobilltype() {
		return vmobilltype;
	}

	public void setVmobilltype(String vmobilltype) {
		this.vmobilltype = vmobilltype;
	}

	public String getVmotrantypeid() {
		return vmotrantypeid;
	}

	public void setVmotrantypeid(String vmotrantypeid) {
		this.vmotrantypeid = vmotrantypeid;
	}

	public String getVmotrantypecode() {
		return vmotrantypecode;
	}

	public void setVmotrantypecode(String vmotrantypecode) {
		this.vmotrantypecode = vmotrantypecode;
	}

	public String getCmooutputid() {
		return cmooutputid;
	}

	public void setCmooutputid(String cmooutputid) {
		this.cmooutputid = cmooutputid;
	}

	public String getVmooutputrowno() {
		return vmooutputrowno;
	}

	public void setVmooutputrowno(String vmooutputrowno) {
		this.vmooutputrowno = vmooutputrowno;
	}

	public String getCmoprocedureid() {
		return cmoprocedureid;
	}

	public void setCmoprocedureid(String cmoprocedureid) {
		this.cmoprocedureid = cmoprocedureid;
	}

	public String getVmoprocedurerowno() {
		return vmoprocedurerowno;
	}

	public void setVmoprocedurerowno(String vmoprocedurerowno) {
		this.vmoprocedurerowno = vmoprocedurerowno;
	}

	public String getCbmaterialid() {
		return (String)getAttributeValue("cbmaterialid");
	}

	public void setCbmaterialid(String cbmaterialid) {
		setAttributeValue("cbmaterialid", cbmaterialid);
	}

	public String getCbmaterialvid() {
		return (String)getAttributeValue(cbmaterialvid);
	}

	public void setCbmaterialvid(String cbmaterialvid) {
		setAttributeValue("cbmaterialvid",cbmaterialvid);
	}

	public String getVbchangerate() {
		return vbchangerate;
	}

	public void setVbchangerate(String vbchangerate) {
		this.vbchangerate = vbchangerate;
	}

	public String getCbunitid() {
		return cbunitid;
	}

	public void setCbunitid(String cbunitid) {
		this.cbunitid = cbunitid;
	}

	public String getCbastunitid() {
		return cbastunitid;
	}

	public void setCbastunitid(String cbastunitid) {
		this.cbastunitid = cbastunitid;
	}

	public String getCbcustomerid() {
		return cbcustomerid;
	}

	public void setCbcustomerid(String cbcustomerid) {
		this.cbcustomerid = cbcustomerid;
	}

	public String getCbcustomervid() {
		return cbcustomervid;
	}

	public void setCbcustomervid(String cbcustomervid) {
		this.cbcustomervid = cbcustomervid;
	}

	public String getCbprojectid() {
		return cbprojectid;
	}

	public void setCbprojectid(String cbprojectid) {
		this.cbprojectid = cbprojectid;
	}

	public String getCbproductorid() {
		return cbproductorid;
	}

	public void setCbproductorid(String cbproductorid) {
		this.cbproductorid = cbproductorid;
	}

	public String getCbvendorid() {
		return cbvendorid;
	}

	public void setCbvendorid(String cbvendorid) {
		this.cbvendorid = cbvendorid;
	}

	public String getCbvendorvid() {
		return cbvendorvid;
	}

	public void setCbvendorvid(String cbvendorvid) {
		this.cbvendorvid = cbvendorvid;
	}

	public String getCbcustmaterialid() {
		return cbcustmaterialid;
	}

	public void setCbcustmaterialid(String cbcustmaterialid) {
		this.cbcustmaterialid = cbcustmaterialid;
	}

	public String getCffileid() {
		return cffileid;
	}

	public void setCffileid(String cffileid) {
		this.cffileid = cffileid;
	}

	public String getVbfree1() {
		return vbfree1;
	}

	public void setVbfree1(String vbfree1) {
		this.vbfree1 = vbfree1;
	}

	public String getVbfree2() {
		return vbfree2;
	}

	public void setVbfree2(String vbfree2) {
		this.vbfree2 = vbfree2;
	}

	public String getVbfree3() {
		return vbfree3;
	}

	public void setVbfree3(String vbfree3) {
		this.vbfree3 = vbfree3;
	}

	public String getVbfree4() {
		return vbfree4;
	}

	public void setVbfree4(String vbfree4) {
		this.vbfree4 = vbfree4;
	}

	public String getVbfree5() {
		return vbfree5;
	}

	public void setVbfree5(String vbfree5) {
		this.vbfree5 = vbfree5;
	}

	public String getVbfree6() {
		return vbfree6;
	}

	public void setVbfree6(String vbfree6) {
		this.vbfree6 = vbfree6;
	}

	public String getVbfree7() {
		return vbfree7;
	}

	public void setVbfree7(String vbfree7) {
		this.vbfree7 = vbfree7;
	}

	public String getVbfree8() {
		return vbfree8;
	}

	public void setVbfree8(String vbfree8) {
		this.vbfree8 = vbfree8;
	}

	public String getVbfree9() {
		return vbfree9;
	}

	public void setVbfree9(String vbfree9) {
		this.vbfree9 = vbfree9;
	}

	public String getVbfree10() {
		return vbfree10;
	}

	public void setVbfree10(String vbfree10) {
		this.vbfree10 = vbfree10;
	}

	public String getVboperationno() {
		return vboperationno;
	}

	public void setVboperationno(String vboperationno) {
		this.vboperationno = vboperationno;
	}

	public String getCboperationtypeid() {
		return cboperationtypeid;
	}

	public void setCboperationtypeid(String cboperationtypeid) {
		this.cboperationtypeid = cboperationtypeid;
	}

	public String getCbwkid() {
		return (String) getAttributeValue("cbwkid");
	}

	public void setCbwkid(String cbwkid) {
		setAttributeValue("cbwkid",cbwkid);
	}

	public String getCbdeptid() {
		return (String)getAttributeValue("cbdeptid");
	}

	public void setCbdeptid(String cbdeptid) {
		setAttributeValue("cbdeptid",cbdeptid);
	}

	public String getCbdeptvid() {
		return (String)getAttributeValue("cbdeptvid");
	}

	public void setCbdeptvid(String cbdeptvid) {
		setAttributeValue("cbdeptvid",cbdeptvid);
	}

	public String getCbshiftid() {
		return cbshiftid;
	}

	public void setCbshiftid(String cbshiftid) {
		this.cbshiftid = cbshiftid;
	}

	public String getCbteamid() {
		return cbteamid;
	}

	public void setCbteamid(String cbteamid) {
		this.cbteamid = cbteamid;
	}

	public String getCbworkman() {
		return cbworkman;
	}

	public void setCbworkman(String cbworkman) {
		this.cbworkman = cbworkman;
	}

	public UFDouble getNboprepnum() {
		return (UFDouble)getAttributeValue("nboprepnum");
	}

	public void setNboprepnum(UFDouble nboprepnum) {
		setAttributeValue("nboprepnum",nboprepnum);
	}

	public UFDouble getNbastoprepnum() {
		return (UFDouble)getAttributeValue("nbastoprepnum");
	}

	public void setNbastoprepnum(UFDouble nbastoprepnum) {
		setAttributeValue("nbastoprepnum",nbastoprepnum);
	}

	public UFDouble getNbqualitynum() {
		return nbqualitynum;
	}

	public void setNbqualitynum(UFDouble nbqualitynum) {
		this.nbqualitynum = nbqualitynum;
	}

	public UFDouble getNbastqualitynum() {
		return nbastqualitynum;
	}

	public void setNbastqualitynum(UFDouble nbastqualitynum) {
		this.nbastqualitynum = nbastqualitynum;
	}

	public UFDouble getNbreworknum() {
		return nbreworknum;
	}

	public void setNbreworknum(UFDouble nbreworknum) {
		this.nbreworknum = nbreworknum;
	}

	public UFDouble getNbastreworknum() {
		return nbastreworknum;
	}

	public void setNbastreworknum(UFDouble nbastreworknum) {
		this.nbastreworknum = nbastreworknum;
	}

	public UFDouble getNbrejectnum() {
		return nbrejectnum;
	}

	public void setNbrejectnum(UFDouble nbrejectnum) {
		this.nbrejectnum = nbrejectnum;
	}

	public UFDouble getNbastrejectnum() {
		return nbastrejectnum;
	}

	public void setNbastrejectnum(UFDouble nbastrejectnum) {
		this.nbastrejectnum = nbastrejectnum;
	}

	public UFDouble getNbtransfernum() {
		return nbtransfernum;
	}

	public void setNbtransfernum(UFDouble nbtransfernum) {
		this.nbtransfernum = nbtransfernum;
	}

	public UFDouble getNbasttransfernum() {
		return nbasttransfernum;
	}

	public void setNbasttransfernum(UFDouble nbasttransfernum) {
		this.nbasttransfernum = nbasttransfernum;
	}

	public UFDouble getNbreworkmonum() {
		return nbreworkmonum;
	}

	public void setNbreworkmonum(UFDouble nbreworkmonum) {
		this.nbreworkmonum = nbreworkmonum;
	}

	public UFDouble getNbastreworkmonum() {
		return nbastreworkmonum;
	}

	public void setNbastreworkmonum(UFDouble nbastreworkmonum) {
		this.nbastreworkmonum = nbastreworkmonum;
	}

	public UFBoolean getBbcheckpoint() {
		return (UFBoolean) getAttributeValue("bbcheckpoint");
	}

	public void setBbcheckpoint(UFBoolean bbcheckpoint) {
		setAttributeValue("bbcheckpoint",bbcheckpoint);
	}

	public UFBoolean getBbreppoint() {
		return (UFBoolean) getAttributeValue("bbreppoint");
	}

	public void setBbreppoint(UFBoolean bbreppoint) {
		setAttributeValue("bbreppoint",bbreppoint);
	}

	public UFDouble getNbastapplychecknum() {
		return nbastapplychecknum;
	}

	public void setNbastapplychecknum(UFDouble nbastapplychecknum) {
		this.nbastapplychecknum = nbastapplychecknum;
	}

	public UFDouble getNbapplychecknum() {
		return nbapplychecknum;
	}

	public void setNbapplychecknum(UFDouble nbapplychecknum) {
		this.nbapplychecknum = nbapplychecknum;
	}

	public UFDouble getNbastapplycheckednum() {
		return nbastapplycheckednum;
	}

	public void setNbastapplycheckednum(UFDouble nbastapplycheckednum) {
		this.nbastapplycheckednum = nbastapplycheckednum;
	}

	public UFDouble getNbapplycheckednum() {
		return nbapplycheckednum;
	}

	public void setNbapplycheckednum(UFDouble nbapplycheckednum) {
		this.nbapplycheckednum = nbapplycheckednum;
	}

	public UFDouble getNbonenum() {
		return nbonenum;
	}

	public void setNbonenum(UFDouble nbonenum) {
		this.nbonenum = nbonenum;
	}

	public UFDouble getNbastonenum() {
		return nbastonenum;
	}

	public void setNbastonenum(UFDouble nbastonenum) {
		this.nbastonenum = nbastonenum;
	}

	public UFDateTime getTbactbegintime() {
		return (UFDateTime)getAttributeValue("tbactbegintime");
	}

	public void setTbactbegintime(UFDateTime tbactbegintime) {
		setAttributeValue("tbactbegintime",tbactbegintime);
	}

	public UFDateTime getTbactendtime() {
		return (UFDateTime)getAttributeValue("tbactendtime");
	}

	public void setTbactendtime(UFDateTime tbactendtime) {
		setAttributeValue("tbactendtime",tbactendtime);
	}

	public String getVbbatchid() {
		return vbbatchid;
	}

	public void setVbbatchid(String vbbatchid) {
		this.vbbatchid = vbbatchid;
	}

	public String getVbbatchcode() {
		return vbbatchcode;
	}

	public void setVbbatchcode(String vbbatchcode) {
		this.vbbatchcode = vbbatchcode;
	}

	public String getCbfirstmoid() {
		return cbfirstmoid;
	}

	public void setCbfirstmoid(String cbfirstmoid) {
		this.cbfirstmoid = cbfirstmoid;
	}

	public String getVbfirstmocode() {
		return vbfirstmocode;
	}

	public void setVbfirstmocode(String vbfirstmocode) {
		this.vbfirstmocode = vbfirstmocode;
	}

	public Integer getFbtransfertype() {
		return (Integer) getAttributeValue("fbtransfertype");
	}

	public void setFbtransfertype(Integer fbtransfertype) {
		setAttributeValue("fbtransfertype",fbtransfertype);
	}

	public Integer getFbbackflushstate() {
		return fbbackflushstate;
	}

	public void setFbbackflushstate(Integer fbbackflushstate) {
		this.fbbackflushstate = fbbackflushstate;
	}

	public UFBoolean getBbbackflush() {
		return bbbackflush;
	}

	public void setBbbackflush(UFBoolean bbbackflush) {
		this.bbbackflush = bbbackflush;
	}

	public UFBoolean getBbconsume() {
		return bbconsume;
	}

	public void setBbconsume(UFBoolean bbconsume) {
		this.bbconsume = bbconsume;
	}

	public String getVfirstid() {
		return vfirstid;
	}

	public void setVfirstid(String vfirstid) {
		this.vfirstid = vfirstid;
	}

	public String getVfirstbid() {
		return vfirstbid;
	}

	public void setVfirstbid(String vfirstbid) {
		this.vfirstbid = vfirstbid;
	}

	public String getVfirsttype() {
		return vfirsttype;
	}

	public void setVfirsttype(String vfirsttype) {
		this.vfirsttype = vfirsttype;
	}

	public String getVfirstcode() {
		return vfirstcode;
	}

	public void setVfirstcode(String vfirstcode) {
		this.vfirstcode = vfirstcode;
	}

	public String getVfirsttranstypeid() {
		return vfirsttranstypeid;
	}

	public void setVfirsttranstypeid(String vfirsttranstypeid) {
		this.vfirsttranstypeid = vfirsttranstypeid;
	}

	public String getVfirsttranstypecode() {
		return vfirsttranstypecode;
	}

	public void setVfirsttranstypecode(String vfirsttranstypecode) {
		this.vfirsttranstypecode = vfirsttranstypecode;
	}

	public String getVfirstrowno() {
		return vfirstrowno;
	}

	public void setVfirstrowno(String vfirstrowno) {
		this.vfirstrowno = vfirstrowno;
	}

	public String getVsrcid() {
		return vsrcid;
	}

	public void setVsrcid(String vsrcid) {
		this.vsrcid = vsrcid;
	}



	public String getVsrctype() {
		return vsrctype;
	}

	public void setVsrctype(String vsrctype) {
		this.vsrctype = vsrctype;
	}

	public String getVsrccode() {
		return vsrccode;
	}

	public void setVsrccode(String vsrccode) {
		this.vsrccode = vsrccode;
	}

	public String getVsrctranstypeid() {
		return vsrctranstypeid;
	}

	public void setVsrctranstypeid(String vsrctranstypeid) {
		this.vsrctranstypeid = vsrctranstypeid;
	}

	public String getVsrctranstypecode() {
		return vsrctranstypecode;
	}

	public void setVsrctranstypecode(String vsrctranstypecode) {
		this.vsrctranstypecode = vsrctranstypecode;
	}

	public String getVsrcrowno() {
		return vsrcrowno;
	}

	public void setVsrcrowno(String vsrcrowno) {
		this.vsrcrowno = vsrcrowno;
	}

	public UFDateTime getTsrcts() {
		return tsrcts;
	}

	public void setTsrcts(UFDateTime tsrcts) {
		this.tsrcts = tsrcts;
	}

	public String getVbdef1() {
		return vbdef1;
	}

	public void setVbdef1(String vbdef1) {
		this.vbdef1 = vbdef1;
	}

	public String getVbdef2() {
		return vbdef2;
	}

	public void setVbdef2(String vbdef2) {
		this.vbdef2 = vbdef2;
	}

	public String getVbdef3() {
		return vbdef3;
	}

	public void setVbdef3(String vbdef3) {
		this.vbdef3 = vbdef3;
	}

	public String getVbdef4() {
		return vbdef4;
	}

	public void setVbdef4(String vbdef4) {
		this.vbdef4 = vbdef4;
	}

	public String getVbdef5() {
		return vbdef5;
	}

	public void setVbdef5(String vbdef5) {
		this.vbdef5 = vbdef5;
	}

	public String getVbdef6() {
		return vbdef6;
	}

	public void setVbdef6(String vbdef6) {
		this.vbdef6 = vbdef6;
	}

	public String getVbdef7() {
		return vbdef7;
	}

	public void setVbdef7(String vbdef7) {
		this.vbdef7 = vbdef7;
	}

	public String getVbdef8() {
		return vbdef8;
	}

	public void setVbdef8(String vbdef8) {
		this.vbdef8 = vbdef8;
	}

	public String getVbdef9() {
		return vbdef9;
	}

	public void setVbdef9(String vbdef9) {
		this.vbdef9 = vbdef9;
	}

	public String getVbdef10() {
		return vbdef10;
	}

	public void setVbdef10(String vbdef10) {
		this.vbdef10 = vbdef10;
	}

	public String getVbdef11() {
		return vbdef11;
	}

	public void setVbdef11(String vbdef11) {
		this.vbdef11 = vbdef11;
	}

	public String getVbdef12() {
		return vbdef12;
	}

	public void setVbdef12(String vbdef12) {
		this.vbdef12 = vbdef12;
	}

	public String getVbdef13() {
		return vbdef13;
	}

	public void setVbdef13(String vbdef13) {
		this.vbdef13 = vbdef13;
	}

	public String getVbdef14() {
		return vbdef14;
	}

	public void setVbdef14(String vbdef14) {
		this.vbdef14 = vbdef14;
	}

	public String getVbdef15() {
		return vbdef15;
	}

	public void setVbdef15(String vbdef15) {
		this.vbdef15 = vbdef15;
	}

	public String getVbdef16() {
		return vbdef16;
	}

	public void setVbdef16(String vbdef16) {
		this.vbdef16 = vbdef16;
	}

	public String getVbdef17() {
		return vbdef17;
	}

	public void setVbdef17(String vbdef17) {
		this.vbdef17 = vbdef17;
	}

	public String getVbdef18() {
		return vbdef18;
	}

	public void setVbdef18(String vbdef18) {
		this.vbdef18 = vbdef18;
	}

	public String getVbdef19() {
		return vbdef19;
	}

	public void setVbdef19(String vbdef19) {
		this.vbdef19 = vbdef19;
	}

	public String getVbdef20() {
		return vbdef20;
	}

	public void setVbdef20(String vbdef20) {
		this.vbdef20 = vbdef20;
	}

	public String getVbnote() {
		return vbnote;
	}

	public void setVbnote(String vbnote) {
		this.vbnote = vbnote;
	}

	public String getCbqid() {
		return cbqid;
	}

	public void setCbqid(String cbqid) {
		this.cbqid = cbqid;
	}

	public Integer getFbqsrctype() {
		return fbqsrctype;
	}

	public void setFbqsrctype(Integer fbqsrctype) {
		this.fbqsrctype = fbqsrctype;
	}

	public Integer getFbqprocessmethod() {
		return (Integer)getAttributeValue("fbqprocessmethod");
	}

	public void setFbqprocessmethod(Integer fbqprocessmethod) {
		setAttributeValue("fbqprocessmethod",fbqprocessmethod);
	}

	public UFBoolean getBbqhaswr() {
		return bbqhaswr;
	}

	public void setBbqhaswr(UFBoolean bbqhaswr) {
		this.bbqhaswr = bbqhaswr;
	}

	public String getCbqqcid() {
		return cbqqcid;
	}

	public void setCbqqcid(String cbqqcid) {
		this.cbqqcid = cbqqcid;
	}

	public String getCbqqcbid() {
		return cbqqcbid;
	}

	public void setCbqqcbid(String cbqqcbid) {
		this.cbqqcbid = cbqqcbid;
	}

	public String getCbqqcorgid() {
		return cbqqcorgid;
	}

	public void setCbqqcorgid(String cbqqcorgid) {
		this.cbqqcorgid = cbqqcorgid;
	}

	public String getCbqqcorgvid() {
		return cbqqcorgvid;
	}

	public void setCbqqcorgvid(String cbqqcorgvid) {
		this.cbqqcorgvid = cbqqcorgvid;
	}

	public String getVbqqcbillcode() {
		return vbqqcbillcode;
	}

	public void setVbqqcbillcode(String vbqqcbillcode) {
		this.vbqqcbillcode = vbqqcbillcode;
	}

	public String getVbqqcrowno() {
		return vbqqcrowno;
	}

	public void setVbqqcrowno(String vbqqcrowno) {
		this.vbqqcrowno = vbqqcrowno;
	}

	public String getFbqdefecttype() {
		return fbqdefecttype;
	}

	public void setFbqdefecttype(String fbqdefecttype) {
		this.fbqdefecttype = fbqdefecttype;
	}

	public String getVbqdefectnote() {
		return vbqdefectnote;
	}

	public void setVbqdefectnote(String vbqdefectnote) {
		this.vbqdefectnote = vbqdefectnote;
	}

	public String getCbqchargepsnid() {
		return cbqchargepsnid;
	}

	public void setCbqchargepsnid(String cbqchargepsnid) {
		this.cbqchargepsnid = cbqchargepsnid;
	}

	public String getCbqchargedeptid() {
		return cbqchargedeptid;
	}

	public void setCbqchargedeptid(String cbqchargedeptid) {
		this.cbqchargedeptid = cbqchargedeptid;
	}

	public String getCbqchargedeptvid() {
		return cbqchargedeptvid;
	}

	public void setCbqchargedeptvid(String cbqchargedeptvid) {
		this.cbqchargedeptvid = cbqchargedeptvid;
	}

	public UFDouble getNbqastnum() {
		return nbqastnum;
	}

	public void setNbqastnum(UFDouble nbqastnum) {
		this.nbqastnum = nbqastnum;
	}

	public UFDouble getNbqnum() {
		return nbqnum;
	}

	public void setNbqnum(UFDouble nbqnum) {
		this.nbqnum = nbqnum;
	}

	public UFDouble getNbqasttransfernum() {
		return nbqasttransfernum;
	}

	public void setNbqasttransfernum(UFDouble nbqasttransfernum) {
		this.nbqasttransfernum = nbqasttransfernum;
	}

	public UFDouble getNbqtransfernum() {
		return nbqtransfernum;
	}

	public void setNbqtransfernum(UFDouble nbqtransfernum) {
		this.nbqtransfernum = nbqtransfernum;
	}

	public UFDouble getNbqastreworkmonum() {
		return nbqastreworkmonum;
	}

	public void setNbqastreworkmonum(UFDouble nbqastreworkmonum) {
		this.nbqastreworkmonum = nbqastreworkmonum;
	}

	public UFDouble getNbqreworkmonum() {
		return nbqreworkmonum;
	}

	public void setNbqreworkmonum(UFDouble nbqreworkmonum) {
		this.nbqreworkmonum = nbqreworkmonum;
	}

	public UFDateTime getTbqts() {
		return tbqts;
	}

	public void setTbqts(UFDateTime tbqts) {
		this.tbqts = tbqts;
	}

	public String getVbqdef1() {
		return vbqdef1;
	}

	public void setVbqdef1(String vbqdef1) {
		this.vbqdef1 = vbqdef1;
	}

	public String getVbqdef2() {
		return vbqdef2;
	}

	public void setVbqdef2(String vbqdef2) {
		this.vbqdef2 = vbqdef2;
	}

	public String getVbqdef3() {
		return vbqdef3;
	}

	public void setVbqdef3(String vbqdef3) {
		this.vbqdef3 = vbqdef3;
	}

	public String getVbqdef4() {
		return vbqdef4;
	}

	public void setVbqdef4(String vbqdef4) {
		this.vbqdef4 = vbqdef4;
	}

	public String getVbqdef5() {
		return vbqdef5;
	}

	public void setVbqdef5(String vbqdef5) {
		this.vbqdef5 = vbqdef5;
	}

	public String getVbqdef6() {
		return vbqdef6;
	}

	public void setVbqdef6(String vbqdef6) {
		this.vbqdef6 = vbqdef6;
	}

	public String getVbqdef7() {
		return vbqdef7;
	}

	public void setVbqdef7(String vbqdef7) {
		this.vbqdef7 = vbqdef7;
	}

	public String getVbqdef8() {
		return vbqdef8;
	}

	public void setVbqdef8(String vbqdef8) {
		this.vbqdef8 = vbqdef8;
	}

	public String getVbqdef9() {
		return vbqdef9;
	}

	public void setVbqdef9(String vbqdef9) {
		this.vbqdef9 = vbqdef9;
	}

	public String getVbqdef10() {
		return vbqdef10;
	}

	public void setVbqdef10(String vbqdef10) {
		this.vbqdef10 = vbqdef10;
	}

	public String getVbqdef11() {
		return vbqdef11;
	}

	public void setVbqdef11(String vbqdef11) {
		this.vbqdef11 = vbqdef11;
	}

	public String getVbqdef12() {
		return vbqdef12;
	}

	public void setVbqdef12(String vbqdef12) {
		this.vbqdef12 = vbqdef12;
	}

	public String getVbqdef13() {
		return vbqdef13;
	}

	public void setVbqdef13(String vbqdef13) {
		this.vbqdef13 = vbqdef13;
	}

	public String getVbqdef14() {
		return vbqdef14;
	}

	public void setVbqdef14(String vbqdef14) {
		this.vbqdef14 = vbqdef14;
	}

	public String getVbqdef15() {
		return vbqdef15;
	}

	public void setVbqdef15(String vbqdef15) {
		this.vbqdef15 = vbqdef15;
	}

	public String getVbqdef16() {
		return vbqdef16;
	}

	public void setVbqdef16(String vbqdef16) {
		this.vbqdef16 = vbqdef16;
	}

	public String getVbqdef17() {
		return vbqdef17;
	}

	public void setVbqdef17(String vbqdef17) {
		this.vbqdef17 = vbqdef17;
	}

	public String getVbqdef18() {
		return vbqdef18;
	}

	public void setVbqdef18(String vbqdef18) {
		this.vbqdef18 = vbqdef18;
	}

	public String getVbqdef19() {
		return vbqdef19;
	}

	public void setVbqdef19(String vbqdef19) {
		this.vbqdef19 = vbqdef19;
	}

	public String getVbqdef20() {
		return vbqdef20;
	}

	public void setVbqdef20(String vbqdef20) {
		this.vbqdef20 = vbqdef20;
	}

	/**
	 * ����name��Setter����.��������dr
	 * ��������:2026-07-06
	 * @ param newName java.lang.Integer
	 */
	public void setDr(java.lang.Integer dr){
		this.dr = dr;
	}
	/**
	 * ����name��Getter����.��������dr
	 * ��������:2026-07-06
	 * @return java.lang.Integer
	 */
	public java.lang.Integer getDr(){
		return this.dr;
	}
	
	/**
	 * ����name��Setter����.��������ts
	 * ��������:2026-07-06
	 * @ param newName nc.vo.pub.lang.UFDateTime
	 */
	public void setTs(nc.vo.pub.lang.UFDateTime ts){
		this.ts = ts;
	}
	/**
	 * ����name��Getter����.��������ts
	 * ��������:2026-07-06
	 * @return nc.vo.pub.lang.UFDateTime
	 */
	public nc.vo.pub.lang.UFDateTime getTs(){
		return this.ts;
	}
	
	
	/**
	 * ����name��Setter����.��������pk_oprep
	 * ��������:2026-07-06
	 * @ param newName java.lang.String
	 */
	public void setPk_oprep(java.lang.String pk_oprep){
		this.pk_oprep = pk_oprep;
	}
	/**
	 * ����name��Getter����.��������pk_oprep
	 * ��������:2026-07-06
	 * @return java.lang.String
	 */
	public java.lang.String getPk_oprep(){
		return this.pk_oprep;
	}
	
	
	public java.lang.String getParentPKFieldName() {
	    return "pk_oprep";
	}   
    
	@Override
	public java.lang.String getPKFieldName() {
	  return "pk_oprep_b";
	}
    
	/**
	 * <p>���ر�����.
	 * <p>
	 * ��������:
	 * @return java.lang.String
	 */
	@Override
	public java.lang.String getTableName() {
		return "mm_operationrep_b";
	}
	
	public static java.lang.String getDefaultTableName() {
		return "mm_operationrep_b";
	}    
    
	@Override
	@nc.vo.annotation.MDEntityInfo(beanFullclassName =  "nc.vo.mmsfc.operationrep.entity.OprepItemVO" )
	public IVOMeta getMetaData() {
		return VOMetaFactory.getInstance().getVOMeta("mmsfc.mm_operationrep_b");
  	}
  	
}
