package nc.syncpro.servlet;

import nc.bs.framework.adaptor.IHttpServletAdaptor;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Logger;

public class teestServlet implements IHttpServletAdaptor {

    private static final Logger LOG = Logger.getLogger("teestServlet");

    @Override
    public void doAction(HttpServletRequest req, HttpServletResponse resp)
            throws IOException {

        resp.setContentType("application/json;charset=UTF-8");
        resp.setCharacterEncoding("UTF-8");

        String method = req.getMethod();
        LOG.info("[teestServlet] �յ�����: " + method + " " + req.getRequestURI()
                + " from " + req.getRemoteAddr());

        PrintWriter out = resp.getWriter();
        try {
            if ("GET".equalsIgnoreCase(method)) {
                handleGet(req, out);
            } else if ("POST".equalsIgnoreCase(method)) {
                handlePost(req, out);
            } else {
                resp.setStatus(405);
                out.print("{\"code\":-1,\"msg\":\"method not allowed: " + method + "\"}");
            }
        } catch (Exception e) {
            LOG.severe("[teestServlet] �����쳣: " + e.getMessage());
            resp.setStatus(500);
            out.print("{\"code\":-1,\"msg\":\"" + escape(e.getMessage()) + "\"}");
        } finally {
            out.flush();
            out.close();
        }
    }

    private void handleGet(HttpServletRequest req, PrintWriter out) {
        String name = req.getParameter("name");
        if (name == null || name.isEmpty()) name = "world";
        out.print("{\"code\":0,\"msg\":\"Hello, " + escape(name) + "! (GET)\"}");
    }

    private void handlePost(HttpServletRequest req, PrintWriter out) throws IOException {
        StringBuilder body = new StringBuilder();
        try (BufferedReader reader = req.getReader()) {
            String line;
            while ((line = reader.readLine()) != null) body.append(line);
        }
        LOG.info("[teestServlet] POST body: " + body);
        out.print("{\"code\":0,\"msg\":\"POST ok\",\"received\":\"" + escape(body.toString()) + "\"}");
    }

    private String escape(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"")
                .replace("\r", "").replace("\n", "\\n");
    }
}
