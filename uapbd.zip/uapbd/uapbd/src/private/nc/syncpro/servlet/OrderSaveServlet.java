package nc.syncpro.servlet;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import nc.bs.framework.adaptor.IHttpServletAdaptor;
import nc.sscpub.json.IJsonUtil;
import nc.syncpro.dto.OrderSaveRequest;
import nc.syncpro.server.OrderSaveServer;
import nc.vo.pub.BusinessException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;


public class OrderSaveServlet implements IHttpServletAdaptor {
    Logger log = Logger.getLogger("OrderSaveServlet");
    OrderSaveServer orderSaveServer = new OrderSaveServer();
    @Override
    public void doAction(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        StringBuilder sb = new StringBuilder();
        String s;
        Map<String,Object> result = new HashMap<>();
        try(BufferedReader reader = req.getReader()) {
            while((s = reader.readLine()) != null){
                if (sb.length() > 0) sb.append('\n');
                sb.append(s);
            }

            String body = sb.toString();
            if(body == null || body.trim().isEmpty()){
                throw new BusinessException("传入参数为空");
            }

            String StringResult = orderSaveServer.save(body);
            JSONObject jsonObject = JSON.parseObject(StringResult);

            Integer code = jsonObject.getInteger("code");
            String message = jsonObject.getString("message");
            result.put("code",code);
            result.put("msg",message);
        if(code == 200){
                //取出字段
                JSONObject data = jsonObject.getJSONObject("data");
                String orderId = data.getString("orderId");
                OrderSaveRequest order = new OrderSaveRequest(orderId);
                result.put("data",order);

        }else {
            throw new BusinessException("查询结果异常！！");
        }


        } catch (IOException e) {
            log.info(e.getMessage());
            throw new IOException();
        } catch (BusinessException e){
            resp.setStatus(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
        }
        resp.setContentType("application/json;charset=UTF-8");
        resp.getOutputStream().write(IJsonUtil.toJson(result).getBytes());
    }
}
