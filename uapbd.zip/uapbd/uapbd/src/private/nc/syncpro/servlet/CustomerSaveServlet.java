package nc.syncpro.servlet;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import nc.bs.framework.adaptor.IHttpServletAdaptor;
import nc.sscpub.json.IJsonUtil;
import nc.syncpro.dto.CustomerSavaDTO;
import nc.syncpro.server.CustomerSaveServer;
import nc.vo.uap.busibean.exception.BusiBeanException;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;


public class CustomerSaveServlet implements IHttpServletAdaptor {

    private static final Logger log = Logger.getLogger("CustomerSaveServlet");

    CustomerSaveServer customerSaveServer = new CustomerSaveServer();
    @Override
    public void doAction(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        resp.setContentType("application/json; charset=UTF-8");

        String bodyJson = null;
        try (BufferedReader reader = req.getReader()) {
            // 1. 读 JSON 请求体（不能用 getParameter，那是 form 专用）
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                if (sb.length() > 0) sb.append('\n');
                sb.append(line);
            }
            bodyJson = sb.toString();
            log.info("[CustomerSaveServlet] 收到请求 body=" + bodyJson);

            // 2. 反序列化
            CustomerSavaDTO request = JSON.parseObject(bodyJson, CustomerSavaDTO.class);

            String jsonString = JSON.toJSONString(request);

            String s = null;
            try {
                s = customerSaveServer.saveCustomer(jsonString);
            } catch (BusiBeanException e) {
                throw new RuntimeException(e);
            }
            JSONObject jsonObject = JSON.parseObject(s);
            Integer code = jsonObject.getInteger("code");
            String message = jsonObject.getString("message");
            Map<String, Object> result = new HashMap<>();;

            if(code == 200){
                //取出字段
                JSONObject data = jsonObject.getJSONObject("data");
                String customerId = data.getString("customerId");
                String customerCode = data.getString("customerCode");
                Map<String, Object> dataMap = new HashMap<>();;
                dataMap.put("customerId",customerId);
                dataMap.put("customerCode",customerCode);

                result.put("code", 200);
                result.put("msg", "操作成功");
                result.put("data", dataMap);
            }else{
                result.put("code", code);
                result.put("msg", message);
                result.put("data", null);
            }

            resp.setStatus(200);
            resp.setContentType("application/json;charset=UTF-8");
            try (OutputStream ops =resp.getOutputStream()){
                ops.write(JSON.toJSONString(result).getBytes("UTF-8"));
                ops.flush();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }
}
