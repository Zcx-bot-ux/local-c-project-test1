package nc.syncpro.servlet;


import com.alibaba.fastjson.JSON;
import nc.bs.framework.adaptor.IHttpServletAdaptor;
import nc.syncpro.dto.WareHouseDTO;
import nc.syncpro.server.WarehouseQueryServer;
import nc.vo.uap.busibean.exception.BusiBeanException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

public class WarehouseQueryServlet implements IHttpServletAdaptor {
    Logger log = Logger.getLogger("WarehouseQueryServlet");
    WarehouseQueryServer warehouseQuery = new WarehouseQueryServer();
    @Override
    public void doAction(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Integer page = Integer.valueOf(req.getParameter("page"));
        Integer pageSize = Integer.valueOf(req.getParameter("pageSize"));
        if (page == 0)
            page = 1;
        if (pageSize == 0)
            pageSize = 10;
        Map<String,Object> result = new HashMap<>();

        try {
            Map<String,Object> queryResult = warehouseQuery.query(page, pageSize);
            resp.setStatus(HttpServletResponse.SC_OK);
            result.put("code", HttpServletResponse.SC_OK);
            result.put("msg", "查询成功");
            result.put("data", queryResult);

        } catch (BusiBeanException e) {
            log.info(e.getMessage());
            resp.setStatus(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
            result.put("code",HttpServletResponse.SC_METHOD_NOT_ALLOWED);
            result.put("msg",e.getMessage());
        }
        resp.setContentType("application/json;charset=UTF-8");
        resp.getOutputStream().write(JSON.toJSONBytes(result));

    }
}
