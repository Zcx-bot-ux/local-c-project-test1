package nc.syncpro.servlet;

import com.alibaba.fastjson.JSON;
import com.yonyou.diwork.exception.BusinessException;
import nc.bs.framework.adaptor.IHttpServletAdaptor;


import nc.sscpub.json.IJsonUtil;
import nc.syncpro.server.MaterialSyncServer;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;


public class MaterialSyncServlet1 implements IHttpServletAdaptor {
    public static final Logger log = Logger.getLogger("MaterialSyncServlet1");
    public MaterialSyncServer materialSyncServer = new MaterialSyncServer();
    @Override
    public void doAction(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Map<String,Object> result = new HashMap<>();
        if (!"POST".equalsIgnoreCase(req.getMethod())) {
            result.put("code", HttpServletResponse.SC_METHOD_NOT_ALLOWED);
            result.put("msg","该接口仅支持post请求");
            resp.setStatus(HttpServletResponse.SC_METHOD_NOT_ALLOWED);


        }

        String ids = req.getParameter("pks");


        try {
            String stringApiResult = materialSyncServer.queryMaterialByIds(ids);
            result.put("code",HttpServletResponse.SC_OK);
            result.put("msg","发送成功");
            result.put("data",stringApiResult);
            resp.setStatus(HttpServletResponse.SC_OK);
        }catch (BusinessException e) {
            log.info(e.getMessage());
            throw new RuntimeException(e);
        }

        resp.setContentType("application/json;charset=UTF-8");
        resp.getOutputStream().write(JSON.toJSONString(result).getBytes(StandardCharsets.UTF_8));


    }


}
