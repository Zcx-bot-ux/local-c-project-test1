package nc.syncpro.servlet;

import com.yonyou.diwork.exception.BusinessException;
import nc.bs.framework.adaptor.IHttpServletAdaptor;
import nc.imag.common.util.IJsonUtil;
import nc.syncpro.server.OrgChartServer;


import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;


public class OrgChartServlet implements IHttpServletAdaptor {
    public static final Logger log = Logger.getLogger("OrgChartServlet");
    OrgChartServer orgChartServer = new OrgChartServer();
    @Override
    public void doAction(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Map<String,Object> result = new HashMap<>();
        String orgMsg;
        try {
            orgMsg = orgChartServer.queryOrg();
            result.put("code",200);
            result.put("msg","查询成功");
            result.put("data",orgMsg);
        } catch (BusinessException e) {
            log.info(e.getMessage());
        }


        resp.setStatus(HttpServletResponse.SC_OK);
        byte[] bytes = IJsonUtil.toJson(result).getBytes(StandardCharsets.UTF_8);
        resp.setContentLength(bytes.length);
        try(OutputStream os = resp.getOutputStream()){
            os.write(bytes);
            os.flush();
        }


    }
}
