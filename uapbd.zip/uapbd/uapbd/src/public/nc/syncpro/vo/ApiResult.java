//package nc.syncpro.vo;
//
//import java.io.Serializable;
//
///**
// * 缁熶竴鍝嶅簲缁撴瀯锛堝鍓嶇 / 澶栭儴绯荤粺缁熶竴杩斿洖锛夈��
// */
//public class ApiResult<T> implements Serializable {
//
//    private static final long serialVersionUID = 1L;
//
//    public static final int CODE_SUCCESS = 0;
//    public static final int CODE_FAIL = -1;
//
//    private Integer code;
//    private String msg;
//    private T data;
//
//    public ApiResult() {
//    }
//
//    public ApiResult(Integer code, String msg, T data) {
//        this.code = code;
//        this.msg = msg;
//        this.data = data;
//    }
//
//    public static <T> ApiResult<T> success() {
//        return new ApiResult<>(CODE_SUCCESS, "success", null);
//    }
//
//    public static <T> ApiResult<T> success(T data) {
//        return new ApiResult<>(CODE_SUCCESS, "success", data);
//    }
//
//    public static <T> ApiResult<T> success(String msg, T data) {
//        return new ApiResult<>(CODE_SUCCESS, msg, data);
//    }
//
//    public static <T> ApiResult<T> fail(String msg) {
//        return new ApiResult<>(CODE_FAIL, msg, null);
//    }
//
//    public static <T> ApiResult<T> fail(Integer code, String msg) {
//        return new ApiResult<>(code, msg, null);
//    }
//
//    public boolean isSuccess() {
//        return code != null && code == CODE_SUCCESS;
//    }
//
//    public Integer getCode() {
//        return code;
//    }
//
//    public void setCode(Integer code) {
//        this.code = code;
//    }
//
//    public String getMsg() {
//        return msg;
//    }
//
//    public void setMsg(String msg) {
//        this.msg = msg;
//    }
//
//    public T getData() {
//        return data;
//    }
//
//    public void setData(T data) {
//        this.data = data;
//    }
//}
