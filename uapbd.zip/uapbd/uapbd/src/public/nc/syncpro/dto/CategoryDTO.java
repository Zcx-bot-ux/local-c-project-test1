package nc.syncpro.dto;

import java.io.Serializable;

/**
 * 物料分类 DTO（基本分�? / �?售分�? / 产品分类 共用此结构）�?
 *
 * �? v1 版本保持�?致，方便前后端协议统�?�?
 */
public class CategoryDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 分类编码（必填） */
    private String code;

    /** 分类名称（必填） */
    private String name;

    /** 上级编码（可选） */
    private String superCode;

    /** 上级名称（可选） */
    private String superName;

    public CategoryDTO() {
    }

    public CategoryDTO(String code, String name) {
        this.code = code;
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSuperCode() {
        return superCode;
    }

    public void setSuperCode(String superCode) {
        this.superCode = superCode;
    }

    public String getSuperName() {
        return superName;
    }

    public void setSuperName(String superName) {
        this.superName = superName;
    }

    @Override
    public String toString() {
        return "CategoryDTO{code='" + code + "', name='" + name
                + "', superCode='" + superCode + "', superName='" + superName + "'}";
    }
}
