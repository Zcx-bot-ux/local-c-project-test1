package nc.syncpro.dto;

import java.util.List;

public class CustomerSavaDTO {
    /**
     * 客户名称【必填】
     */
    private String customerName;

    /**
     * 客户简称【必填】
     */
    private String shortName;

    /**
     * 客户分类【必填】
     */
    private String customerCategory;

    /**
     * 客户电话【必填】
     */
    private String phone;

    /**
     * 客户类型【必填】
     */
    private String customerType;

    /**
     * 渠道类型【必填】
     */
    private String channelType;

    /**
     * 客户联系人/授权账号列表【非必填】
     */
    private List<CustomerContactDTO> contactList;

    /**
     * 所属业务员id【必填】
     */
    private String salesId;

    /**
     * 所属营盘id【必填】
     */
    private String campId;

    /**
     * 上级客户id 二级客户绑定一级客户使用【非必填】
     */
    private String superCustomerId;

    /**
     * 状态：1启用 0停用【必填】
     */
    private String status;

    /** 扩展字段1 */
    private String ext1;
    /** 扩展字段2 */
    private String ext2;
    /** 扩展字段3 */
    private String ext3;
    /** 扩展字段4 */
    private String ext4;
    /** 扩展字段5 */
    private String ext5;

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getShortName() {
        return shortName;
    }

    public void setShortName(String shortName) {
        this.shortName = shortName;
    }

    public String getCustomerCategory() {
        return customerCategory;
    }

    public void setCustomerCategory(String customerCategory) {
        this.customerCategory = customerCategory;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getCustomerType() {
        return customerType;
    }

    public void setCustomerType(String customerType) {
        this.customerType = customerType;
    }

    public String getChannelType() {
        return channelType;
    }

    public void setChannelType(String channelType) {
        this.channelType = channelType;
    }

    public List<CustomerContactDTO> getContactList() {
        return contactList;
    }

    public void setContactList(List<CustomerContactDTO> contactList) {
        this.contactList = contactList;
    }

    public String getSalesId() {
        return salesId;
    }

    public void setSalesId(String salesId) {
        this.salesId = salesId;
    }

    public String getCampId() {
        return campId;
    }

    public void setCampId(String campId) {
        this.campId = campId;
    }

    public String getSuperCustomerId() {
        return superCustomerId;
    }

    public void setSuperCustomerId(String superCustomerId) {
        this.superCustomerId = superCustomerId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getExt1() {
        return ext1;
    }

    public void setExt1(String ext1) {
        this.ext1 = ext1;
    }

    public String getExt2() {
        return ext2;
    }

    public void setExt2(String ext2) {
        this.ext2 = ext2;
    }

    public String getExt3() {
        return ext3;
    }

    public void setExt3(String ext3) {
        this.ext3 = ext3;
    }

    public String getExt4() {
        return ext4;
    }

    public void setExt4(String ext4) {
        this.ext4 = ext4;
    }

    public String getExt5() {
        return ext5;
    }

    public void setExt5(String ext5) {
        this.ext5 = ext5;
    }
}
