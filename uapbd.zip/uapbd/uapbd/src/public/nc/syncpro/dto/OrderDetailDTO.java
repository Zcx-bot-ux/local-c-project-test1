package nc.syncpro.dto;

public class OrderDetailDTO {
    private String materialId;      // 物料id
    private Integer packages;       // 包数
    private Double weight;          // 重量
    private Double amount;          // 金额
    private Boolean isFreeGift;     // 是否赠品
    private Double deductPoints;    // 消耗积分
    private String ext1;            // 明细扩展字段1
    private String ext2;            // 明细扩展字段2
    private String ext3;            // 明细扩展字段3
    private String ext4;            // 明细扩展字段4
    private String ext5;            // 明细扩展字段5

    public String getMaterialId() {
        return materialId;
    }

    public void setMaterialId(String materialId) {
        this.materialId = materialId;
    }

    public Integer getPackages() {
        return packages;
    }

    public void setPackages(Integer packages) {
        this.packages = packages;
    }

    public Double getWeight() {
        return weight;
    }

    public void setWeight(Double weight) {
        this.weight = weight;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public Boolean getFreeGift() {
        return isFreeGift;
    }

    public void setFreeGift(Boolean freeGift) {
        isFreeGift = freeGift;
    }

    public Double getDeductPoints() {
        return deductPoints;
    }

    public void setDeductPoints(Double deductPoints) {
        this.deductPoints = deductPoints;
    }

    public String getExt1() {
        return ext1;
    }

    public void setExt1(String ext1) {
        this.ext1 = ext1;
    }

    public String getExt2() {
        return ext2;
    }

    public void setExt2(String ext2) {
        this.ext2 = ext2;
    }

    public String getExt3() {
        return ext3;
    }

    public void setExt3(String ext3) {
        this.ext3 = ext3;
    }

    public String getExt4() {
        return ext4;
    }

    public void setExt4(String ext4) {
        this.ext4 = ext4;
    }

    public String getExt5() {
        return ext5;
    }

    public void setExt5(String ext5) {
        this.ext5 = ext5;
    }
}
