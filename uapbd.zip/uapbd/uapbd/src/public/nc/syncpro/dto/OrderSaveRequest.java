package nc.syncpro.dto;

import java.util.List;

public class OrderSaveRequest {
    public OrderSaveRequest(){

    }

    public OrderSaveRequest(String orderId){
        this.orderId = orderId;
    }
    private String orderId;                // 订单id（为空时新增）
    private String orderFlag;              // 订单标识（本、挂、养、代）
    private String customerId;             // 客户id
    private String preparedBy;             // 制单人
    private String creator;                // 创建人
    private String pickTime;               // 计划提货时间
    private String deliveryTimeSlot;       // 请求交货时段
    private Boolean hasGiftMaterial;       // 是否携带赠料
    private String factoryId;              // 工厂ID
    private Boolean isDirectShipment;      // 是否直运
    private String outCompanyId;           // 调出公司id
    private String outWarehouseId;         // 调出仓库id
    private String remark;                 // 备注
    private String tradeType;              // 订单类型
    private Boolean hasRebate;             // 是否返利
    private Boolean isPreOrder;            // 是否提前下单
    private Double totalWeight;            // 总重量
    private Double totalAmount;            // 总金额
    private List<OrderDetailDTO> orderDetails;  // 订单明细列表
    private String ext1;                   // 扩展字段1
    private String ext2;                   // 扩展字段2
    private String ext3;                   // 扩展字段3
    private String ext4;                   // 扩展字段4
    private String ext5;                   // 扩展字段5

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getOrderFlag() {
        return orderFlag;
    }

    public void setOrderFlag(String orderFlag) {
        this.orderFlag = orderFlag;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getPreparedBy() {
        return preparedBy;
    }

    public void setPreparedBy(String preparedBy) {
        this.preparedBy = preparedBy;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public String getPickTime() {
        return pickTime;
    }

    public void setPickTime(String pickTime) {
        this.pickTime = pickTime;
    }

    public String getDeliveryTimeSlot() {
        return deliveryTimeSlot;
    }

    public void setDeliveryTimeSlot(String deliveryTimeSlot) {
        this.deliveryTimeSlot = deliveryTimeSlot;
    }

    public Boolean getHasGiftMaterial() {
        return hasGiftMaterial;
    }

    public void setHasGiftMaterial(Boolean hasGiftMaterial) {
        this.hasGiftMaterial = hasGiftMaterial;
    }

    public String getFactoryId() {
        return factoryId;
    }

    public void setFactoryId(String factoryId) {
        this.factoryId = factoryId;
    }

    public Boolean getIsDirectShipment() {
        return isDirectShipment;
    }

    public void setIsDirectShipment(Boolean directShipment) {
        this.isDirectShipment = directShipment;
    }

    public String getOutCompanyId() {
        return outCompanyId;
    }

    public void setOutCompanyId(String outCompanyId) {
        this.outCompanyId = outCompanyId;
    }

    public String getOutWarehouseId() {
        return outWarehouseId;
    }

    public void setOutWarehouseId(String outWarehouseId) {
        this.outWarehouseId = outWarehouseId;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getTradeType() {
        return tradeType;
    }

    public void setTradeType(String tradeType) {
        this.tradeType = tradeType;
    }

    public Boolean getHasRebate() {
        return hasRebate;
    }

    public void setHasRebate(Boolean hasRebate) {
        this.hasRebate = hasRebate;
    }

    public Boolean getIsPreOrder() {
        return isPreOrder;
    }

    public void setPreOrder(Boolean preOrder) {
        isPreOrder = preOrder;
    }

    public Double getTotalWeight() {
        return totalWeight;
    }

    public void setTotalWeight(Double totalWeight) {
        this.totalWeight = totalWeight;
    }

    public Double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(Double totalAmount) {
        this.totalAmount = totalAmount;
    }

    public List<OrderDetailDTO> getOrderDetails() {
        return orderDetails;
    }

    public void setOrderDetails(List<OrderDetailDTO> orderDetails) {
        this.orderDetails = orderDetails;
    }

    public String getExt1() {
        return ext1;
    }

    public void setExt1(String ext1) {
        this.ext1 = ext1;
    }

    public String getExt2() {
        return ext2;
    }

    public void setExt2(String ext2) {
        this.ext2 = ext2;
    }

    public String getExt3() {
        return ext3;
    }

    public void setExt3(String ext3) {
        this.ext3 = ext3;
    }

    public String getExt4() {
        return ext4;
    }

    public void setExt4(String ext4) {
        this.ext4 = ext4;
    }

    public String getExt5() {
        return ext5;
    }

    public void setExt5(String ext5) {
        this.ext5 = ext5;
    }
}
