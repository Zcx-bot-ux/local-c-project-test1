package nc.syncpro.dto;

import java.io.Serializable;

/**
 * 鐗╂枡妗ｆ瀵瑰鍚屾 DTO銆?
 *
 * 涓? v1 鐨勫尯鍒細
 * - 澧炲姞闈欐?佸伐鍘? {@link #ofId(String)}锛岀敤浜? DELETE 鍦烘櫙鍙～涓婚敭锛?
 * - 瀛楁瀹氫箟涓庡皬绋嬪簭鎺ュ彛鏂囨。 2.1.2 淇濇寔涓?鑷淬??
 */
public class MaterialDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    private String materialId;
    private String materialCode;
    private String materialName;
    private CategoryDTO baseCategory;
    private CategoryDTO salesCategory;
    private CategoryDTO productCategory;
    private String specification;
    private String mainUnit;
    private String mainUnitName;
    private String unit;
    private String unitName;
    private String conversionRate;
    private String tonPointConversionRate;
    private String taxType;
    private String brand;
    private String createTime;
    private String updateTime;
    private String status;
    private String ext1;
    private String ext2;
    private String ext3;
    private String ext4;
    private String ext5;

    /**
     * 鍒犻櫎鍦烘櫙涓撶敤锛氬彧濉? materialId锛屽叾浠栧瓧娈典负 null銆?
     * 灏忕▼搴忔寜 actionType=DELETE 鏃跺彧璇诲彇 materialId銆?
     */
    public static MaterialDTO ofId(String materialId) {
        MaterialDTO dto = new MaterialDTO();
        dto.materialId = materialId;
        return dto;
    }

    public String getMaterialId() {
        return materialId;
    }

    public void setMaterialId(String materialId) {
        this.materialId = materialId;
    }

    public String getMaterialCode() {
        return materialCode;
    }

    public void setMaterialCode(String materialCode) {
        this.materialCode = materialCode;
    }

    public String getMaterialName() {
        return materialName;
    }

    public void setMaterialName(String materialName) {
        this.materialName = materialName;
    }

    public CategoryDTO getBaseCategory() {
        return baseCategory;
    }

    public void setBaseCategory(CategoryDTO baseCategory) {
        this.baseCategory = baseCategory;
    }

    public CategoryDTO getSalesCategory() {
        return salesCategory;
    }

    public void setSalesCategory(CategoryDTO salesCategory) {
        this.salesCategory = salesCategory;
    }

    public CategoryDTO getProductCategory() {
        return productCategory;
    }

    public void setProductCategory(CategoryDTO productCategory) {
        this.productCategory = productCategory;
    }

    public String getSpecification() {
        return specification;
    }

    public void setSpecification(String specification) {
        this.specification = specification;
    }

    public String getMainUnit() {
        return mainUnit;
    }

    public void setMainUnit(String mainUnit) {
        this.mainUnit = mainUnit;
    }

    public String getMainUnitName() {
        return mainUnitName;
    }

    public void setMainUnitName(String mainUnitName) {
        this.mainUnitName = mainUnitName;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getUnitName() {
        return unitName;
    }

    public void setUnitName(String unitName) {
        this.unitName = unitName;
    }

    public String getConversionRate() {
        return conversionRate;
    }

    public void setConversionRate(String conversionRate) {
        this.conversionRate = conversionRate;
    }

    public String getTonPointConversionRate() {
        return tonPointConversionRate;
    }

    public void setTonPointConversionRate(String tonPointConversionRate) {
        this.tonPointConversionRate = tonPointConversionRate;
    }

    public String getTaxType() {
        return taxType;
    }

    public void setTaxType(String taxType) {
        this.taxType = taxType;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getExt1() {
        return ext1;
    }

    public void setExt1(String ext1) {
        this.ext1 = ext1;
    }

    public String getExt2() {
        return ext2;
    }

    public void setExt2(String ext2) {
        this.ext2 = ext2;
    }

    public String getExt3() {
        return ext3;
    }

    public void setExt3(String ext3) {
        this.ext3 = ext3;
    }

    public String getExt4() {
        return ext4;
    }

    public void setExt4(String ext4) {
        this.ext4 = ext4;
    }

    public String getExt5() {
        return ext5;
    }

    public void setExt5(String ext5) {
        this.ext5 = ext5;
    }

    @Override
    public String toString() {
        return "MaterialDTO{materialId='" + materialId + "', materialCode='" + materialCode
                + "', materialName='" + materialName + "', status='" + status + "'}";
    }
}
