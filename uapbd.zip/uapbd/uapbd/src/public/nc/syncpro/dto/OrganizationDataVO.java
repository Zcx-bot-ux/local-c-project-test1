package nc.syncpro.dto;

import java.io.Serializable;
import java.util.List;

/** 用来产生 { "organization": [...] } 这种 data 结构 */
public class OrganizationDataVO implements Serializable {
    private static final long serialVersionUID = 1L;

    private List<OrganizationDTO> organization;

    public OrganizationDataVO() {}

    public OrganizationDataVO(List<OrganizationDTO> organization) {
        this.organization = organization;
    }

    public List<OrganizationDTO> getOrganization() { return organization; }
    public void setOrganization(List<OrganizationDTO> organization) { this.organization = organization; }
}
