package nc.syncpro.util;

import nc.bs.logging.Logger;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Map;

/**
 * HTTP 调用工具（基于 JDK HttpURLConnection，不依赖 Spring）。
 */
public final class HttpClientUtil {

    private static final int CONNECT_TIMEOUT_MS = 10_000;
    private static final int READ_TIMEOUT_MS = 60_000;
    private static final String USER_AGENT = "NCC-MaterialSync/1.0";

    private HttpClientUtil() {}

    public static String postJson(String url, String jsonBody, Map<String, String> extraHeaders) {
        HttpURLConnection conn = null;
        try {
            URL u = new URL(url);
            conn = (HttpURLConnection) u.openConnection();
            conn.setRequestMethod("POST");
            conn.setConnectTimeout(CONNECT_TIMEOUT_MS);
            conn.setReadTimeout(READ_TIMEOUT_MS);
            conn.setDoOutput(true);
            conn.setDoInput(true);
            conn.setUseCaches(false);
            conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            conn.setRequestProperty("Accept", "application/json");
            conn.setRequestProperty("User-Agent", USER_AGENT);
            if (extraHeaders != null && !extraHeaders.isEmpty()) {
                for (Map.Entry<String, String> e : extraHeaders.entrySet()) {
                    if (e.getKey() != null && e.getValue() != null) {
                        conn.setRequestProperty(e.getKey(), e.getValue());
                    }
                }
            }

            byte[] body = jsonBody == null ? new byte[0] : jsonBody.getBytes(StandardCharsets.UTF_8);
            conn.setFixedLengthStreamingMode(body.length);

            try (OutputStream os = conn.getOutputStream()) {
                os.write(body);
                os.flush();
            }

            int status = conn.getResponseCode();
            boolean ok = status >= 200 && status < 300;
            InputStream is = ok ? conn.getInputStream() : conn.getErrorStream();
            String resp = readAll(is);

            if (!ok) {
                String msg = "HTTP 调用失败, status=" + status + ", body=" + resp;
                Logger.error(msg);
                throw new RuntimeException(msg);
            }
            return resp;
        } catch (RuntimeException e) {
            throw e;
        } catch (Exception e) {
            String msg = "HTTP 调用异常: " + e.getMessage();
            Logger.error(msg, e);
            throw new RuntimeException(msg, e);
        } finally {
            if (conn != null) conn.disconnect();
        }
    }
    private static String readAll(InputStream is) {
        if (is == null) return "";
        StringBuilder sb = new StringBuilder();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
            String line;
            while ((line = r.readLine()) != null) {
                if (sb.length() > 0) sb.append('\n');
                sb.append(line);
            }
        } catch (Exception e) {
            Logger.warn("[HttpClientUtil] 读取响应体失败: " + e.getMessage());
        }
        return sb.toString();
    }
}
