package nc.syncpro.util;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;

/**
 * 缃戝叧绛惧悕宸ュ叿锛歮d5(sha256(appSecret + nonce + timestamp))銆�
 */
public final class SignatureUtil {

    public static final String HEADER_APPID = "x-gw-appid";
    public static final String HEADER_TIMESTAMP = "x-gw-timestamp";
    public static final String HEADER_NONCE = "x-gw-nonce";
    public static final String HEADER_SIGNATURE = "x-gw-signature";

    private SignatureUtil() {
    }

    public static Map<String, String> buildHeaders(String appId, String appSecret) {
        long now = System.currentTimeMillis();
        String timestamp = Long.toString(now / 1000L);
        String nonce = Long.toHexString(now) + "-" + Long.toHexString((long) Math.floor(Math.random() * 0xFFFFFF));

        String sign = md5(sha256(appSecret + nonce + timestamp));

        Map<String, String> headers = new HashMap<>(8);
        headers.put(HEADER_APPID, appId);
        headers.put(HEADER_TIMESTAMP, timestamp);
        headers.put(HEADER_NONCE, nonce);
        headers.put(HEADER_SIGNATURE, sign);
        return headers;
    }

    private static String sha256(final String text) {
        if (text == null || text.isEmpty()) {
            return null;
        }
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(text.getBytes());
            return toHex(md.digest());
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-256 涓嶅彲鐢�: " + e.getMessage(), e);
        }
    }

    private static String md5(final String text) {
        if (text == null || text.isEmpty()) {
            return null;
        }
        try {
            byte[] bytes = MessageDigest.getInstance("MD5").digest(text.getBytes());
            String hex = new BigInteger(1, bytes).toString(16);
            StringBuilder sb = new StringBuilder(32);
            for (int i = 0; i < 32 - hex.length(); i++) {
                sb.append('0');
            }
            return sb.append(hex).toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("MD5 涓嶅彲鐢�: " + e.getMessage(), e);
        }
    }

    private static String toHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1) {
                sb.append('0');
            }
            sb.append(hex);
        }
        return sb.toString();
    }
}
