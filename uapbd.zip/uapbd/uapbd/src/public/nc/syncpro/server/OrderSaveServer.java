package nc.syncpro.server;


import com.alibaba.fastjson.JSON;
import nc.syncpro.dto.OrderDetailDTO;
import nc.syncpro.dto.OrderSaveRequest;
import nc.syncpro.util.HttpClientUtil;
import nc.vo.uap.busibean.exception.BusiBeanException;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import static nc.util.iufo.pub.UFOString.isEmpty;


public class OrderSaveServer {
    Logger log = Logger.getLogger("OrderSaveServer");
    private static final String url = "pu/orde/operation/save";
    public String save(String body) throws BusiBeanException {

        OrderSaveRequest param = JSON.parseObject(body, OrderSaveRequest.class);
        String s = validateRequest(param);
        if(s != null){
            log.info(s);
            throw new BusiBeanException(s);
        }
        String s1;
        try {
            s1 = HttpClientUtil.postJson(url, body, new HashMap<String, String>());
        } catch (Exception e) {
            throw new BusiBeanException("调用结果失败！"+ e.getMessage());
        }
        return s1;


    }
    private String validateRequest(OrderSaveRequest request) {
        if (request == null) {
            return "请求参数不能为空";
        }

        // 必填字段校验
        if (isEmpty(request.getOrderFlag())) {
            return "orderFlag 不能为空";
        }
        if (isEmpty(request.getCustomerId())) {
            return "customerId 不能为空";
        }
        if (isEmpty(request.getPreparedBy())) {
            return "preparedBy 不能为空";
        }
        if (isEmpty(request.getCreator())) {
            return "creator 不能为空";
        }
        if (isEmpty(request.getPickTime())) {
            return "pickTime 不能为空";
        }
        if (isEmpty(request.getDeliveryTimeSlot())) {
            return "deliveryTimeSlot 不能为空";
        }
        if (request.getHasGiftMaterial() == null) {
            return "hasGiftMaterial 不能为空";
        }
        if (isEmpty(request.getFactoryId())) {
            return "factoryId 不能为空";
        }
        if (request.getIsDirectShipment() == null) {
            return "isDirectShipment 不能为空";
        }
        if (isEmpty(request.getTradeType())) {
            return "tradeType 不能为空";
        }
        if (request.getHasRebate() == null) {
            return "hasRebate 不能为空";
        }
        if (request.getIsPreOrder() == null) {
            return "isPreOrder 不能为空";
        }
        if (request.getTotalWeight() == null) {
            return "totalWeight 不能为空";
        }
        if (request.getTotalAmount() == null) {
            return "totalAmount 不能为空";
        }
        if (request.getOrderDetails() == null || request.getOrderDetails().isEmpty()) {
            return "orderDetails 不能为空";
        }

        // 明细列表校验
        for (OrderDetailDTO detail : request.getOrderDetails()) {
            if (isEmpty(detail.getMaterialId())) {
                return "明细中 materialId 不能为空";
            }
            if (detail.getPackages() == null) {
                return "明细中 packages 不能为空";
            }
            if (detail.getWeight() == null) {
                return "明细中 weight 不能为空";
            }
            if (detail.getAmount() == null) {
                return "明细中 amount 不能为空";
            }
        }

        return null;  // 校验通过
    }
}
