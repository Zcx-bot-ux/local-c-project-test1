package nc.syncpro.server;

import nc.syncpro.util.HttpClientUtil;
import nc.syncpro.util.SignatureUtil;
import nc.vo.uap.busibean.exception.BusiBeanException;
import org.apache.http.Header;
import org.json.JSONString;

import java.util.HashMap;
import java.util.Map;



public class CustomerSaveServer {
    private static final String url = "uapbd/customer/customerbiptoncc/savecustomer";

    public String saveCustomer(String jsonString) throws BusiBeanException {
        Map<String, String> header = new HashMap<>();
        String s;
        try {
            s = HttpClientUtil.postJson(url, jsonString, header);

        } catch (Exception e) {

            throw new BusiBeanException("保存客户失败！！");
        }
        return s;
    }
}
