package nc.syncpro.server;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.yonyou.diwork.exception.BusinessException;
import nc.bs.dao.BaseDAO;
import nc.bs.dao.DAOException;
import nc.jdbc.framework.processor.MapListProcessor;
import nc.sscpub.json.IJsonUtil;
import nc.syncpro.dto.CategoryDTO;
import nc.syncpro.dto.MaterialDTO;
import nc.syncpro.util.HttpClientUtil;
import nc.syncpro.util.SignatureUtil;


import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;



public class MaterialSyncServer {
    public static final Logger log = Logger.getLogger("MaterialSyncServer");
    public static final String DATE_PATTERN = "yyyy-MM-dd HH:mm:ss";
    private static final String MINI_SYNC_URL = "https://api.example.com/api/material/sync";
    private static final String APP_ID = "15115";
    private static final String APP_SECRET = "1111";
    BaseDAO baseDao = new BaseDAO();
    public String queryMaterialByIds(String ids) throws BusinessException {
        if(ids == null || ids.trim().isEmpty()){
//            return ApiResult.fail("ids 不能为空");
            throw new BusinessException("ids 不能为空");
        }
        List<String> arr = JSON.parseArray(ids, String.class);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < arr.size(); i++) {
            if (i > 0) sb.append(",");
            String item = arr.get(i);

            // 判断第一个字符是不是双引号 " 或单引号 '
            if (item.startsWith("\"") || item.startsWith("'")) {
                // 去掉首尾的引号
                item = item.substring(1, item.length() - 1);
            }
            sb.append("'").append(item).append("'");
        }
        StringBuilder sql = new StringBuilder(getSQL());
        if(sb != null && sb.isEmpty()) {
            sql.append("AND m.pk_material IN (").append(sb).append(") ")
                    .append("ORDER BY m.modifiedtime ASC ");
        }
        List<MaterialDTO> materials = new ArrayList<>();
        try {
            List<Map<String, Object>> rows = (List<Map<String, Object>>)baseDao.executeQuery(sql.toString(), new MapListProcessor());
            for (Map<String, Object> row : rows) {
                MaterialDTO material = convertRow(row);
                materials.add(material);
            }
        }catch(DAOException e){
            log.info("查询失败：" + e.getMessage());
            throw new BusinessException("按ID查询物料失败!");
        }
        if(materials.size() == 0){
            throw new BusinessException("物料查询结果为空!");
        }

        return sendMini(materials);
    }

    private String getSQL(){
        return "SELECT \n" +
                "m.pk_material as materialId,\n" +
                "m.code as materialCode,\n" +
                "m.name as materialName,\n" +
                "base.code as baseCode,\n" +
                "base.name as baseName,\n" +
                "baseFather.code as baseSuperCode,\n" +
                "baseFather.name as baseSuperName,\n" +
//                "saleClass.code as saleCode,\n" +
//                "saleClass.name as saleName,\n" +
//                "saleClassFather.code as saleSuperCode,\n" +
//                "saleClassFather.name as saleSuperName,\n" +
                "base.code as saleCode,\n" +
                "base.name as saleName,\n" +
                "baseFather.code as saleSuperCode,\n" +
                "baseFather.name as saleSuperName,\n" +
                "base.code as productClassCode,\n" +//产品分类名称
                "base.name as productClassName,\n" +//产品分类名称
                "m.materialspec as specification,\n" +
                "measdoc.pk_measdoc    as mainUnit,\n" +
                "measdoc.name  as mainUnitName,\n" +
                "measdoc2.pk_measdoc as unit,\n" +
                "measdoc2.name  as unitName,\n" +
                "convert.measrate as conversionRate,\n" +
                "1 as tonPointConversionRate,\n" +
                "mattaxes.mattaxesname as taxType,\n" +
                "branddoc.name as brand,\n" +
                "m.creationtime as createTime,\n" +
                "m.modifiedtime as updateTime,\n" +
                "m.enablestate as status,\n" +
                "m.def1 as ext1,\n" +
                "m.def2 as ext2,\n" +
                "m.def3 as ext3,\n" +
                "m.def4 as ext4,\n" +
                "m.def5 as ext5 \n" +
                "from ncc10.bd_material m \n" +
                "left join ncc10.bd_marbasclass base on base.pk_marbasclass = m.pk_marbasclass \n" +
                "left join ncc10.bd_marbasclass baseFather on base.pk_parent = baseFather.pk_marbasclass \n" +
                "left join ncc10.bd_materialsale saleMes on m.pk_material = saleMes.pk_material \n" +
//                "left join ncc10.pk_marsaleclass saleClass on saleMes.pk_marsaleclass = saleClass.pk_marsaleclass \n" +
//                "left join ncc10.pk_marsaleclass saleClassFather on saleClass.pk_father = saleClassFather.pk_marsaleclass \n" +
                "left join ncc10.bd_measdoc measdoc on m.pk_measdoc = measdoc.pk_measdoc \n" +
                "left join ncc10.bd_materialconvert convert on convert.pk_material = m.pk_material \n" +
                "left join ncc10.bd_measdoc measdoc2 on convert.pk_measdoc = measdoc2.pk_measdoc \n" +
                "left join ncc10.bd_mattaxes mattaxes on m.pk_mattaxes = mattaxes.pk_mattaxes \n" +
                "left join ncc10.bd_branddoc branddoc on m.pk_brand = branddoc.pk_brand \n" +
                "WHERE m.dr = 0 ";
    }
    public String sendMini(List<MaterialDTO> m) throws BusinessException{

        try{
            Map<String, String> headers = SignatureUtil.buildHeaders(APP_ID, APP_SECRET );
            String body = IJsonUtil.toJson(m);
            String respJson  = HttpClientUtil.postJson(MINI_SYNC_URL, body, headers);

            return respJson;
//            // 把小程序返回的 {code,msg,data} 透传
//            @SuppressWarnings("unchecked")
//            Map<String, Object> resp = JSON.parseObject(respJson);
//            Object code = resp.get("code");
//            boolean ok = Integer.valueOf(0).equals(code) || Integer.valueOf(200).equals(code);
//            if (ok) {
//                return ApiResult.success(body);
//            }
//            return ApiResult.fail(JSON.toJSONString(resp.get("msg")));
        } catch (Exception e) {
            log.info("推送小程序异常: " + e.getMessage());
            throw new BusinessException("推送小程序异常: " + e.getMessage());
        }

    }

    private MaterialDTO convertRow(Map<String, Object> row) {
        MaterialDTO dto = new MaterialDTO();
        dto.setMaterialId(JSON.toJSONString(row.get("materialId")));
        dto.setMaterialCode(JSON.toJSONString(row.get("materialCode")));
        dto.setMaterialName(JSON.toJSONString(row.get("materialName")));
        dto.setSpecification(JSON.toJSONString(row.get("specification")));
        dto.setMainUnit(JSON.toJSONString(row.get("mainUnit")));
        dto.setMainUnitName(JSON.toJSONString(row.get("mainUnitName")));
        dto.setUnit(JSON.toJSONString(row.get("unit")));
        dto.setUnitName(JSON.toJSONString(row.get("unitName")));
        dto.setConversionRate(JSON.toJSONString(row.get("conversionRate")));
        dto.setTonPointConversionRate(JSON.toJSONString(row.get("tonPointConversionRate")));
        dto.setTaxType(JSON.toJSONString(row.get("taxType")));
        dto.setBrand(JSON.toJSONString(row.get("brand")));
        dto.setCreateTime(formatTimestamp(row.get("createTimeRaw")));
        dto.setUpdateTime(formatTimestamp(row.get("updateTimeRaw")));

        String enableState = JSON.toJSONString(row.get("enableState"));
        dto.setStatus("2".equals(enableState) ? "1" : "0");

        dto.setExt1(JSON.toJSONString(row.get("ext1")));
        dto.setExt2(JSON.toJSONString(row.get("ext2")));
        dto.setExt3(JSON.toJSONString(row.get("ext3")));
        dto.setExt4(JSON.toJSONString(row.get("ext4")));
        dto.setExt5(JSON.toJSONString(row.get("ext5")));

        CategoryDTO base = new CategoryDTO();
        base.setCode(JSON.toJSONString(row.get("baseCode")));
        base.setName(JSON.toJSONString(row.get("baseName")));
        base.setSuperCode(JSON.toJSONString(row.get("baseSuperCode")));
        base.setSuperName(JSON.toJSONString(row.get("baseSuperName")));
        dto.setBaseCategory(base);

        CategoryDTO sale = new CategoryDTO();
        sale.setCode(JSON.toJSONString(row.get("saleCode")));
        sale.setName(JSON.toJSONString(row.get("saleName")));
        sale.setSuperCode(JSON.toJSONString(row.get("saleSuperCode")));
        sale.setSuperName(JSON.toJSONString(row.get("saleSuperName")));
        dto.setSalesCategory(sale);

        CategoryDTO prod = new CategoryDTO();
        prod.setCode(JSON.toJSONString(row.get("productClassCode")));
        prod.setName(JSON.toJSONString(row.get("productClassName")));
        dto.setProductCategory(prod);

        return dto;
    }
    private String formatTimestamp(Object v) {
        if (v == null) return null;
        if (v instanceof Timestamp) return new SimpleDateFormat(DATE_PATTERN).format((Timestamp) v);
        String s = v.toString();
        if (s.length() == 14 && s.matches("\\d{14}")) {
            return s.substring(0, 4) + "-" + s.substring(4, 6) + "-" + s.substring(6, 8)
                    + " " + s.substring(8, 10) + ":" + s.substring(10, 12) + ":" + s.substring(12, 14);
        }
        return s;
    }
}
