package nc.syncpro.server;

import nc.bs.dao.BaseDAO;
import nc.bs.dao.DAOException;
import nc.jdbc.framework.processor.BeanListProcessor;
import nc.syncpro.dto.WareHouseDTO;
import nc.vo.uap.busibean.exception.BusiBeanException;

import java.util.HashMap;
import java.util.Map;

public class WarehouseQueryServer {
    public Map<String,Object> query(Integer page, Integer pageSize) throws BusiBeanException {
        String s = SqlBuilder(page, pageSize);
        BaseDAO base = new BaseDAO();
        WareHouseDTO queryResult;
        try {
            queryResult = (WareHouseDTO)base.executeQuery(s, new BeanListProcessor(WareHouseDTO.class));

        } catch (DAOException e) {
            throw new BusiBeanException("查询数据异常！！");
        }
        if(queryResult == null){
            queryResult = new WareHouseDTO();
        }

        Map<String,Object> dataResult = new HashMap<>();
        dataResult.put("page",page);
        dataResult.put("pageSize",pageSize);
        dataResult.put("page",page * pageSize);
        dataResult.put("warehouseList",queryResult);
        return dataResult;
    }

    private String SqlBuilder(Integer page, Integer pageSize){
        Integer startRow = (page - 1) * pageSize;
        Integer endRow = page * pageSize;
//        return "SELECT \n" +
//                "\torg.pk_stockorg as inventory_org_id,\n" +
//                "\tstordoc.pk_stordoc as warehouse_id,\n" +
//                "\tstordoc.code as warehouse_code,\n" +
//                "\tstordoc.name as warehouse_name,\n" +
//                "\tregion.pk_region as region_id,\n" +
//                "\torg_group.pk_group as camp_id,\n" +
//                "\tstordoc.creationtime\tas start_time,\n" +
//                "\tstordoc.modifiedtime\tas end_time,\n" +
//                "\tstordoc.creationtime as create_time,\n" +
//                "\tstordoc.modifiedtime as update_time,\n" +
//                "\tstordoc.mrpflag as is_default,\n" +
//                "\tstordoc.enablestate as status,\n" +
//                "\tstordoc.def1 as ext1,\n" +
//                "\tstordoc.def2 as ext2,\n" +
//                "\tstordoc.def3 as ext3,\n" +
//                "\tstordoc.def4 as ext4,\n" +
//                "\tstordoc.def5 as ext5 \n" +
//                "FROM\n" +
//                "\tBD_STORDOC stordoc\n" +
//                "\tleft join org_stockorg org on stordoc.pk_org = org.pk_stockorg\n" +
//                "\tleft join bd_addressdoc address on stordoc.pk_address = address.pk_addressdoc\n" +
//                "\tleft join bd_region region on address.province = region.pk_region\n" +
//                "\tleft join org_group on stordoc.pk_group = org_group.pk_group\n" +
//                "ORDER BY\n" +
//                "\twarehouse_code \n" +
//                " ";
        return "SELECT * FROM (\n" +
                "SELECT \n" +
                "\torg.pk_stockorg as inventoryOrgId,\n" +
                "\tstordoc.pk_stordoc as warehouseId,\n" +
                "\tstordoc.code as warehouseCode,\n" +
                "\tstordoc.name as warehouseName,\n" +
                "\tregion.pk_region as regionId,\n" +
                "\torg_group.pk_group as campId,\n" +
                "\tstordoc.creationtime as startTime,\n" +
                "\tstordoc.modifiedtime as endTime,\n" +
                "\tstordoc.creationtime as createTime,\n" +
                "\tstordoc.modifiedtime as updateTime,\n" +
                "\tstordoc.mrpflag as isDefault,\n" +
                "\tstordoc.enablestate as status,\n" +
                "\tstordoc.def1 as ext1,\n" +
                "\tstordoc.def2 as ext2,\n" +
                "\tstordoc.def3 as ext3,\n" +
                "\tstordoc.def4 as ext4,\n" +
                "\tstordoc.def5 as ext5,\n" +
                "\t ROWNUM AS rn\n" +
                "FROM\n" +
                "\tncc10.BD_STORDOC stordoc\n" +
                "\tleft join ncc10.org_stockorg org on stordoc.pk_org = org.pk_stockorg\n" +
                "\tleft join ncc10.bd_addressdoc address on stordoc.pk_address = address.pk_addressdoc\n" +
                "\tleft join ncc10.bd_region region on address.province = region.pk_region\n" +
                "\tleft join ncc10.org_group org_group on stordoc.pk_group = org_group.pk_group\n" +
                "-- ORDER BY\n" +
                "-- \twarehouse_code \n" +
                "-- \tlimit 10 offset 3\n" +
                "-- OFFSET 3 ROWS FETCH NEXT 10 ROWS ONLY WHERE ROWNUM <= 13   -- offset(3) + limit(10) = 13\n" +
                " WHERE ROWNUM <= "+ endRow +"   -- offset(3) + limit(10) = 13\n" +
                "\n" +
                ") WHERE rn > "+startRow+"   -- offset = 3";
    }
}
