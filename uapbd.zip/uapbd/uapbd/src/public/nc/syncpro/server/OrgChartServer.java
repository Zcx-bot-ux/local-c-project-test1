package nc.syncpro.server;

import com.yonyou.diwork.exception.BusinessException;
import nc.bs.dao.BaseDAO;
import nc.bs.dao.DAOException;
import nc.jdbc.framework.processor.BeanListProcessor;
import nc.sscpub.json.IJsonUtil;
import nc.syncpro.dto.OrganizationDTO;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

public class OrgChartServer {
    public static final Logger log = Logger.getLogger("OrgChartServer");
    BaseDAO dao = new BaseDAO();
    public String queryOrg() throws BusinessException {
        String sql = buildBaseSelectSql();
        List<OrganizationDTO> orgList;
        try {
            orgList = (List<OrganizationDTO>)dao.executeQuery(sql, new BeanListProcessor(OrganizationDTO.class));
        } catch (DAOException e) {
            log.info("查询结果异常");
            throw new BusinessException("查询结果异常");
        }
        if(orgList.size() == 0){
            orgList = new ArrayList<>();
        }
        return IJsonUtil.toJson(orgList);


    }
    private String buildBaseSelectSql() {
        return "SELECT \n" +
                "    org.pk_org AS orgId,\n" +
                "    org.code AS orgCode,\n" +
                "    org.name AS orgName,\n" +
                "    psndoc.name AS orgHeadId,\n" +
                "    org2.pk_org AS superOrgId,\n" +
                "    org.isbusinessunit AS isOrg,\n" +
                "    org.enablestate as status,\n" +
                "    org.creationtime AS createTime,\n" +
                "    org.modifiedtime AS updateTime,\n" +
                "    org.def1 as ext1,\n" +
                "    org.def2 as ext2,\n" +
                "    org.def3 as ext3,\n" +
                "    org.def4 as ext4,\n" +
                "    org.def5 as ext5\n" +
                "from ncc10.org_admorgmember_v admorgmember\n" +
                "left join ncc10.org_orgs org on admorgmember.pk_org = org.pk_org\n" +
                "left join ncc10.bd_psndoc psndoc on org.principal = psndoc.pk_psndoc\n" +
                "left join ncc10.org_orgs org2 on admorgmember.pk_fatherorg = org2.pk_org";
    }
}
